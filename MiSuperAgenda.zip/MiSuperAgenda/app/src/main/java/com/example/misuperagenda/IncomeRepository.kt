package com.example.misuperagenda.data.repository

import com.example.misuperagenda.data.database.FinancialAccountDao
import com.example.misuperagenda.data.database.IncomeDao
import com.example.misuperagenda.data.model.Income
import com.example.misuperagenda.data.model.IncomeStatus
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull

class IncomeRepository(
    private val incomeDao: IncomeDao,
    private val financialAccountDao: FinancialAccountDao
) {

    val allIncomes: Flow<List<Income>> = incomeDao.getAllIncomes()

    /**
     * Inserta o actualiza un Ingreso y maneja la conciliación del saldo de la cuenta.
     *
     * @param income El objeto Income a guardar.
     */
    suspend fun insertOrUpdateIncome(income: Income) {
        val originalIncome = if (income.id != 0) incomeDao.getIncomeById(income.id) else null

        // 1. Revertir cambios si el ingreso original ya estaba aplicado al saldo
        if (originalIncome != null && originalIncome.hasAppliedToBalance) {
            val account = financialAccountDao.getAccountById(originalIncome.accountId)
            if (account != null) {
                val newBalance = account.balance - originalIncome.amount
                financialAccountDao.update(account.copy(balance = newBalance))
            }
        }

        // 2. Determinar si el nuevo registro debe aplicar al saldo
        val shouldApply = income.status == IncomeStatus.COBRADO

        val incomeToSave = income.copy(
            hasAppliedToBalance = shouldApply // Marca el registro como aplicado (si está Cobrado)
        )

        incomeDao.insert(incomeToSave)

        // 3. Aplicar cambios al saldo de la cuenta SOLO si el estado es COBRADO
        if (shouldApply) {
            val account = financialAccountDao.getAccountById(income.accountId)
            if (account != null) {
                val newBalance = account.balance + income.amount
                financialAccountDao.update(account.copy(balance = newBalance))
            }
        }
    }
    suspend fun deleteIncome(income: Income) {
        if (income.hasAppliedToBalance) {
            val account = financialAccountDao.getAccountById(income.accountId)
            if (account != null) {
                // Revertir: restar el monto del ingreso eliminado
                val newBalance = account.balance - income.amount
                financialAccountDao.update(account.copy(balance = newBalance))
            }
        }
        incomeDao.delete(income)
    }
    suspend fun getIncomeById(id: Int): Income? {
        return incomeDao.getIncomeById(id)
    }
}