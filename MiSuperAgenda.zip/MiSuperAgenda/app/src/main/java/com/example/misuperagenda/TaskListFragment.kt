package com.example.misuperagenda.ui.fragments

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.misuperagenda.data.model.Categoria
import com.example.misuperagenda.data.model.Event
import com.example.misuperagenda.databinding.FragmentTaskListBinding
import com.example.misuperagenda.ui.EventDetailActivity
import com.example.misuperagenda.ui.adapter.EventAdapter
import com.example.misuperagenda.ui.viewmodel.EventViewModel
import com.example.misuperagenda.data.database.AppDatabase
import com.example.misuperagenda.data.repository.EventRepository
import com.example.misuperagenda.ui.viewmodel.EventViewModelFactory

class TaskListFragment : Fragment() {
    private var _binding: FragmentTaskListBinding? = null
    private val binding get() = _binding!!

    // Configuración del ViewModel
    private val eventViewModel: EventViewModel by activityViewModels {
        val database = AppDatabase.getDatabase(requireContext())
        val eventDao = database.eventDao()
        val repository = EventRepository(eventDao)
        EventViewModelFactory(repository)
    }

    private lateinit var eventAdapter: EventAdapter
    private val TAG = "TaskListFragment" // Mantener un TAG si se necesita debug

    // Ciclo de Vida del Fragmento (limpio de Toasts y Logs innecesarios)
    override fun onAttach(context: Context) {
        super.onAttach(context)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        retainInstance = true
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentTaskListBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecyclerView()
        setupListeners()
        setupFilterSpinner()
        observeEvents()
    }

    private fun setupFilterSpinner() {
        val categoryOptions = Categoria.entries.map { it.name }.toMutableList()
        categoryOptions.add(0, "TODOS") // La posición 0 es para NO filtrar

        val adapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_dropdown_item,
            categoryOptions
        )

        binding.spinnerFilterCategory.adapter = adapter
        binding.spinnerFilterCategory.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {
                if (position == 0) {
                    eventViewModel.setCategoryFilter(null)
                    binding.buttonClearFilter.visibility = View.GONE
                } else {
                    // Restamos 1 porque la posición 0 es "TODOS"
                    val selectedCategory = Categoria.entries[position - 1]
                    eventViewModel.setCategoryFilter(selectedCategory)
                    binding.buttonClearFilter.visibility = View.VISIBLE
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>) {
                // No se necesita hacer nada
            }
        }

        binding.buttonClearFilter.setOnClickListener {
            binding.spinnerFilterCategory.setSelection(0)
        }
        binding.buttonClearFilter.visibility = View.GONE
    }

    private fun setupRecyclerView() {
        eventAdapter = EventAdapter { event ->
            val intent = EventDetailActivity.newIntent(requireContext(), event.id)
            startActivity(intent)
        }
        binding.recyclerViewEvents.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = eventAdapter
        }
    }

    private fun setupListeners() {
        binding.fabAddEvent.setOnClickListener {
            val intent = EventDetailActivity.newIntent(requireContext())
            startActivity(intent)
        }
    }

    private fun observeEvents() {
        // Observa la lista filtrada de eventos
        eventViewModel.eventsToDisplay.observe(viewLifecycleOwner) { events ->
            eventAdapter.submitList(events)
            // Lógica para mostrar mensaje si no hay eventos después de filtrar
            if (events.isEmpty() && binding.spinnerFilterCategory.selectedItemPosition == 0) {
                binding.textNoEvents.visibility = View.VISIBLE
                binding.textNoEvents.text = "¡Aún no tienes tareas creadas!"
            } else if (events.isEmpty() && binding.spinnerFilterCategory.selectedItemPosition != 0) {
                binding.textNoEvents.visibility = View.VISIBLE
                binding.textNoEvents.text = "No hay tareas para la categoría seleccionada."
            }
            else {
                binding.textNoEvents.visibility = View.GONE
            }
        }
    }

    // MÉTODOS DE CICLO DE VIDA LIMPIOS
    override fun onStart() { super.onStart() }
    override fun onResume() { super.onResume() }
    override fun onPause() { super.onPause() }
    override fun onStop() { super.onStop() }
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
    override fun onDestroy() {
        super.onDestroy()
    }
}
