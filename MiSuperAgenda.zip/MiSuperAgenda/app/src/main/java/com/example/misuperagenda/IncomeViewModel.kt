package com.example.misuperagenda.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.example.misuperagenda.data.model.Income
import com.example.misuperagenda.data.repository.IncomeRepository
import kotlinx.coroutines.launch

class IncomeViewModel(private val repository: IncomeRepository) : ViewModel() {

    // Lista de todos los ingresos observados por la UI
    val allIncomes = repository.allIncomes.asLiveData(viewModelScope.coroutineContext)

    fun insertOrUpdate(income: Income) = viewModelScope.launch {
        repository.insertOrUpdateIncome(income)
    }

    fun delete(income: Income) = viewModelScope.launch {
        repository.deleteIncome(income)
    }

    suspend fun getIncomeById(id: Int): Income? {
        return repository.getIncomeById(id)
    }
}

class IncomeViewModelFactory(private val repository: IncomeRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(IncomeViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return IncomeViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}