package com.example.misuperagenda.ui.viewmodel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.example.misuperagenda.data.model.Categoria
import com.example.misuperagenda.data.model.Event
import com.example.misuperagenda.data.repository.EventRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
class EventViewModel(val repository: EventRepository) : ViewModel() {
    private val _currentFilter = MutableStateFlow<Categoria?>(null)
    val currentFilter: StateFlow<Categoria?> = _currentFilter
    fun setCategoryFilter(category: Categoria?) {
        _currentFilter.value = category
    }
    private val allEventsFlow = repository.allEvents
    val eventsToDisplay = allEventsFlow.combine(_currentFilter) { events, filter ->
        if (filter == null) {
            events // Mostrar todos si no hay filtro
        } else {
            events.filter { it.category == filter } // Aplicar filtro de categoría
        }
    }.asLiveData() // Exponer como LiveData para la UI
    fun insertOrUpdate(event: Event, onResult: (Boolean, String?) -> Unit) = viewModelScope.launch {
        val resultId = repository.insertOrUpdateEvent(event)
        if (resultId > 0) {
            onResult(true, "Evento guardado exitosamente.")
        } else if (resultId == -1L) {
            onResult(false, "ERROR: El evento se solapa con otro evento existente. Cámbialo o conviértelo en Alarma.")
        } else {
            onResult(false, "ERROR desconocido al guardar el evento.")
        }
    }
    fun delete(event: Event) = viewModelScope.launch {
        repository.deleteEvent(event)
    }
}
class EventViewModelFactory(private val repository: EventRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(EventViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return EventViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}