package com.example.misuperagenda.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.misuperagenda.data.model.FinancialAccount
import com.example.misuperagenda.data.repository.FinancialAccountRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class FinancialAccountViewModel(private val repository: FinancialAccountRepository) : ViewModel() {

    private val _allAccounts = MutableStateFlow<List<FinancialAccount>>(emptyList())
    val allAccounts: StateFlow<List<FinancialAccount>> = _allAccounts.asStateFlow()

    val institutions: Flow<List<String>> = repository.institutions

    init {
        // Solo cargar las cuentas existentes, sin datos de prueba
        viewModelScope.launch {
            repository.allAccounts.collect { accounts ->
                _allAccounts.value = accounts
            }
        }
    }

    fun insert(account: FinancialAccount) = viewModelScope.launch {
        repository.insertAccount(account)
    }

    fun update(account: FinancialAccount) = viewModelScope.launch {
        repository.updateAccount(account)
    }

    fun delete(account: FinancialAccount) = viewModelScope.launch {
        repository.deleteAccount(account)
    }

    fun getAccountById(id: Int): FinancialAccount? {
        return _allAccounts.value.find { it.id == id }
    }

    suspend fun getAccountByIdFromDb(id: Int): FinancialAccount? {
        return repository.getAccountById(id)
    }

    fun getAccountsByInstitution(institution: String): Flow<List<FinancialAccount>> {
        return repository.getAccountsByInstitution(institution)
    }
}

class FinancialAccountViewModelFactory(
    private val repository: FinancialAccountRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(FinancialAccountViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return FinancialAccountViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}