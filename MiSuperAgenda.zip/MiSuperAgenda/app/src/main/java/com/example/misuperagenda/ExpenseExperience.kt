package com.example.misuperagenda.data.model

enum class ExpenseExperience {
    BUENA, REGULAR, MALA
}