package com.example.misuperagenda.ui

import android.app.Activity
import android.app.DatePickerDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.misuperagenda.R
import com.example.misuperagenda.data.database.AppDatabase
import com.example.misuperagenda.data.model.FinancialAccount
import com.example.misuperagenda.data.model.Income
import com.example.misuperagenda.data.model.IncomeStatus
import com.example.misuperagenda.data.model.IncomeType
import com.example.misuperagenda.data.repository.FinancialAccountRepository
import com.example.misuperagenda.data.repository.IncomeRepository
import com.example.misuperagenda.databinding.ActivityIncomeDetailBinding
import com.example.misuperagenda.ui.viewmodel.FinancialAccountViewModel
import com.example.misuperagenda.ui.viewmodel.FinancialAccountViewModelFactory
import com.example.misuperagenda.ui.viewmodel.IncomeViewModel
import com.example.misuperagenda.ui.viewmodel.IncomeViewModelFactory
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.format.DateTimeParseException
import java.util.Calendar

class IncomeDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityIncomeDetailBinding
    private var incomeId: Int = 0
    private var currentIncome: Income? = null
    private var selectedDate: LocalDate = LocalDate.now()

    // ViewModels
    private val incomeViewModel: IncomeViewModel by viewModels {
        val database = AppDatabase.getDatabase(applicationContext)
        val incomeDao = database.incomeDao()
        val financialAccountDao = database.financialAccountDao()
        val repository = IncomeRepository(incomeDao, financialAccountDao)
        IncomeViewModelFactory(repository)
    }

    private val financialAccountViewModel: FinancialAccountViewModel by viewModels {
        val database = AppDatabase.getDatabase(applicationContext)
        val repository = FinancialAccountRepository(database.financialAccountDao())
        FinancialAccountViewModelFactory(repository)
    }

    // Vistas
    private lateinit var textDetailTitle: TextView
    private lateinit var editTitle: TextInputEditText
    private lateinit var buttonSelectDate: Button
    private lateinit var editAmount: TextInputEditText
    private lateinit var spinnerAccount: Spinner
    private lateinit var spinnerIncomeType: Spinner
    private lateinit var spinnerIncomeStatus: Spinner
    private lateinit var editDescription: TextInputEditText
    private lateinit var buttonSave: Button
    private lateinit var buttonDelete: Button

    // Datos para Spinners
    private var accountList: List<FinancialAccount> = emptyList()

    companion object {
        private const val EXTRA_INCOME_ID = "com.example.misuperagenda.INCOME_ID"

        fun newIntent(context: Context, incomeId: Int = 0): Intent {
            return Intent(context, IncomeDetailActivity::class.java).apply {
                putExtra(EXTRA_INCOME_ID, incomeId)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityIncomeDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        incomeId = intent.getIntExtra(EXTRA_INCOME_ID, 0)

        // Inicializar vistas con el binding
        textDetailTitle = binding.textDetailTitle
        editTitle = binding.editTitle
        buttonSelectDate = binding.buttonSelectDate
        editAmount = binding.editAmount
        spinnerAccount = binding.spinnerAccount
        spinnerIncomeType = binding.spinnerIncomeType
        spinnerIncomeStatus = binding.spinnerIncomeStatus
        editDescription = binding.editDescription
        buttonSave = binding.buttonSave
        buttonDelete = binding.buttonDelete

        setupSpinners()
        setupListeners()

        if (incomeId != 0) {
            textDetailTitle.text = "Editar Ingreso"
            buttonDelete.visibility = View.VISIBLE
            loadIncomeData(incomeId)
        } else {
            updateDateButtonText()
            textDetailTitle.text = "Nuevo Ingreso"
            buttonDelete.visibility = View.GONE
        }
    }

    private fun setupSpinners() {
        // Spinner Tipo de Ingreso
        val incomeTypeAdapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            IncomeType.entries.map { it.name }
        )
        spinnerIncomeType.adapter = incomeTypeAdapter

        // Spinner Estado de Ingreso
        val incomeStatusAdapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            IncomeStatus.entries.map { it.name }
        )
        spinnerIncomeStatus.adapter = incomeStatusAdapter

        // Spinner Cuentas Bancarias
        lifecycleScope.launch {
            financialAccountViewModel.allAccounts.collect { accounts ->
                accountList = accounts
                val accountNames = accounts.map { "${it.institution} (${it.accountType})" }
                val accountAdapter = ArrayAdapter(
                    this@IncomeDetailActivity,
                    android.R.layout.simple_spinner_dropdown_item,
                    accountNames
                )
                spinnerAccount.adapter = accountAdapter

                // Recargar datos si es edición y las cuentas se cargaron más tarde
                if (incomeId != 0 && currentIncome != null) {
                    prepopulateFields()
                }
            }
        }
    }

    private fun setupListeners() {
        buttonSelectDate.setOnClickListener {
            showDatePickerDialog()
        }
        buttonSave.setOnClickListener {
            validateAndSaveIncome()
        }
        buttonDelete.setOnClickListener {
            showDeleteConfirmationDialog()
        }
    }

    private fun loadIncomeData(id: Int) = lifecycleScope.launch {
        currentIncome = incomeViewModel.getIncomeById(id)
        if (currentIncome == null) {
            Toast.makeText(this@IncomeDetailActivity, "Ingreso no encontrado.", Toast.LENGTH_SHORT).show()
            finish()
            return@launch
        }
        // Si las cuentas ya están cargadas, precargar campos. Si no, se hace en el 'collect' del Spinner.
        if (accountList.isNotEmpty()) {
            prepopulateFields()
        }
    }

    private fun prepopulateFields() {
        currentIncome?.let { income ->
            editTitle.setText(income.title)
            editDescription.setText(income.description)
            editAmount.setText(income.amount.toString())

            selectedDate = income.incomeDate.toLocalDate()
            updateDateButtonText()

            // Preseleccionar Tipo de Ingreso
            val typePosition = IncomeType.entries.indexOf(income.type)
            if (typePosition != -1) {
                spinnerIncomeType.setSelection(typePosition)
            }

            // Preseleccionar Estado
            val statusPosition = IncomeStatus.entries.indexOf(income.status)
            if (statusPosition != -1) {
                spinnerIncomeStatus.setSelection(statusPosition)
            }

            // Preseleccionar Cuenta
            val accountPosition = accountList.indexOfFirst { it.id == income.accountId }
            if (accountPosition != -1) {
                spinnerAccount.setSelection(accountPosition)
            }
        }
    }

    private fun showDatePickerDialog() {
        val calendar = Calendar.getInstance().apply {
            set(selectedDate.year, selectedDate.monthValue - 1, selectedDate.dayOfMonth)
        }

        DatePickerDialog(
            this,
            { _, year, month, dayOfMonth ->
                selectedDate = LocalDate.of(year, month + 1, dayOfMonth)
                updateDateButtonText()
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    private fun updateDateButtonText() {
        val formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy")
        buttonSelectDate.text = selectedDate.format(formatter)
    }

    private fun validateAndSaveIncome() {
        val title = editTitle.text.toString().trim()
        val amountStr = editAmount.text.toString().trim()
        val description = editDescription.text.toString().trim()
        val selectedAccountIndex = spinnerAccount.selectedItemPosition

        if (title.isEmpty() || amountStr.isEmpty() || selectedDate == null || selectedAccountIndex == -1 || accountList.isEmpty()) {
            Toast.makeText(this, "Por favor, completa todos los campos obligatorios.", Toast.LENGTH_LONG).show()
            return
        }

        val amount: Double
        try {
            amount = amountStr.toDouble()
            if (amount <= 0) throw NumberFormatException()
        } catch (e: NumberFormatException) {
            Toast.makeText(this, "El monto debe ser un número positivo válido.", Toast.LENGTH_LONG).show()
            return
        }

        val selectedAccount = accountList[selectedAccountIndex]
        val selectedType = IncomeType.valueOf(spinnerIncomeType.selectedItem.toString())
        val selectedStatus = IncomeStatus.valueOf(spinnerIncomeStatus.selectedItem.toString())

        val incomeToSave = currentIncome?.copy(
            title = title,
            incomeDate = selectedDate.atStartOfDay(),
            accountId = selectedAccount.id,
            description = description.ifEmpty { null },
            amount = amount,
            type = selectedType,
            status = selectedStatus,
            // Importante: hasAppliedToBalance es gestionado por el Repository, no por la UI aquí
        ) ?: Income(
            title = title,
            incomeDate = selectedDate.atStartOfDay(),
            accountId = selectedAccount.id,
            description = description.ifEmpty { null },
            amount = amount,
            type = selectedType,
            status = selectedStatus,
            // Importante: hasAppliedToBalance es gestionado por el Repository, no por la UI aquí
        )

        incomeViewModel.insertOrUpdate(incomeToSave)

        val action = if (incomeId == 0) "guardado" else "editado"
        Toast.makeText(this, "Ingreso $action exitosamente.", Toast.LENGTH_SHORT).show()
        setResult(Activity.RESULT_OK)
        finish()
    }

    private fun showDeleteConfirmationDialog() {
        AlertDialog.Builder(this)
            .setTitle("Confirmar Eliminación")
            .setMessage("¿Estás seguro de que quieres eliminar este Ingreso?")
            .setPositiveButton("Sí, Eliminar") { dialog, _ ->
                currentIncome?.let { income ->
                    incomeViewModel.delete(income)
                    Toast.makeText(this, "Ingreso eliminado.", Toast.LENGTH_SHORT).show()
                    setResult(Activity.RESULT_OK)
                    finish()
                }
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }
}