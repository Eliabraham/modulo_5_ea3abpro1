package com.example.misuperagenda

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.activity.viewModels
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import com.example.misuperagenda.data.database.AppDatabase
import com.example.misuperagenda.data.repository.EventRepository
import com.example.misuperagenda.databinding.ActivityMainBinding
import com.example.misuperagenda.ui.viewmodel.EventViewModel
import com.example.misuperagenda.ui.viewmodel.EventViewModelFactory
class MainActivity : AppCompatActivity() {
    private val TAG = "LifeCycleActivity"
    companion object {
        const val EDIT_TASK_REQUEST_CODE = 1
    }
    private lateinit var binding: ActivityMainBinding
    private val eventViewModel: EventViewModel by viewModels {
        val database = AppDatabase.getDatabase(applicationContext)
        val repository = EventRepository(database.eventDao())
        EventViewModelFactory(repository)
    }
    private val requestPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted: Boolean ->
            if (isGranted) {
                Toast.makeText(this, "Permiso de notificaciones concedido.", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Permiso de notificaciones denegado.", Toast.LENGTH_LONG).show()
            }
        }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        setupNavigation()
        // Solo navegar si viene de WelcomeActivity
        val selectedSection = intent.getStringExtra("SELECTED_SECTION")
        selectedSection?.let {
            navigateToSection(it)
        }
        requestNotificationPermission()
    }
    private fun setupNavigation() {
        val navHostFragment = supportFragmentManager
            .findFragmentById(R.id.nav_host_fragment) as NavHostFragment
        val navController = navHostFragment.navController
        // Configurar la barra de navegación inferior
        binding.bottomNavigation.setupWithNavController(navController)
        // Agregar listener personalizado para debugging
        binding.bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.taskListFragment -> {
                    navController.navigate(R.id.taskListFragment)
                    true
                }
                R.id.expenseListFragment -> {
                    navController.navigate(R.id.expenseListFragment)
                    true
                }
                R.id.incomeListFragment -> {
                    navController.navigate(R.id.incomeListFragment)
                    true
                }
                R.id.bankAccountListFragment -> {
                    navController.navigate(R.id.bankAccountListFragment)
                    true
                }
                else -> false
            }
        }
    }
    private fun navigateToSection(section: String) {
        val navHostFragment = supportFragmentManager
            .findFragmentById(R.id.nav_host_fragment) as NavHostFragment
        val navController = navHostFragment.navController
        when (section) {
            "events" -> {
                navController.navigate(R.id.taskListFragment)
                binding.bottomNavigation.selectedItemId = R.id.taskListFragment
            }
            "expenses" -> {
                navController.navigate(R.id.expenseListFragment)
                binding.bottomNavigation.selectedItemId = R.id.expenseListFragment
            }
            "income" -> {
                navController.navigate(R.id.incomeListFragment)
                binding.bottomNavigation.selectedItemId = R.id.incomeListFragment
            }
            "accounts" -> {
                navController.navigate(R.id.bankAccountListFragment)
                binding.bottomNavigation.selectedItemId = R.id.bankAccountListFragment
            }
        }
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == EDIT_TASK_REQUEST_CODE) {
            if (resultCode == Activity.RESULT_OK) {
                val action = data?.getStringExtra("action") ?: "guardada"
                Toast.makeText(this, "Tarea $action con éxito.", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Edición de tarea cancelada.", Toast.LENGTH_SHORT).show()
            }
        }
    }
    override fun onStart() {super.onStart() }
    override fun onResume() {super.onResume() }
    override fun onPause() {super.onPause() }
    override fun onStop() {super.onStop() }
    override fun onDestroy() {super.onDestroy() }
    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)) {
                Toast.makeText(this, "La aplicación necesita permiso de notificación para mostrar tus recordatorios a tiempo.", Toast.LENGTH_LONG).show()
            }
            requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
}
