package com.example.misuperagenda
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.misuperagenda.databinding.ActivityWelcomeBinding
class WelcomeActivity : AppCompatActivity() {
    private lateinit var binding: ActivityWelcomeBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWelcomeBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setupClickListeners()
    }
    private fun setupClickListeners() {
        binding.cardEvents.setOnClickListener {
            startMainActivityWithSection("events")
        }
        binding.cardExpenses.setOnClickListener {
            startMainActivityWithSection("expenses")
        }
        binding.cardIncome.setOnClickListener {
            startMainActivityWithSection("income")
        }
        binding.cardAccounts.setOnClickListener {
            startMainActivityWithSection("accounts")
        }
    }
    private fun startMainActivityWithSection(section: String) {
        val intent = Intent(this, MainActivity::class.java).apply {
            putExtra("SELECTED_SECTION", section)
        }
        startActivity(intent)
    }
}