package com.example.misuperagenda.data.model

enum class IncomeStatus {
    POR_COBRAR,
    COBRADO
}