package com.example.misuperagenda.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.example.misuperagenda.data.model.Expense
import com.example.misuperagenda.data.model.ExpenseWithItems
import com.example.misuperagenda.data.repository.ExpenseRepository
import kotlinx.coroutines.launch

class ExpenseViewModel(private val repository: ExpenseRepository) : ViewModel() {

    // ✅ CORREGIDO: Usar directamente el repository del constructor
    val allExpenses = repository.allExpenses.asLiveData()

    fun insertOrUpdate(expenseWithItems: ExpenseWithItems) = viewModelScope.launch {
        repository.insertOrUpdateExpenseWithItems(expenseWithItems)
    }

    fun delete(expense: Expense) = viewModelScope.launch {
        repository.deleteExpense(expense)
    }

    suspend fun getExpenseById(id: Int): Expense? {
        return repository.getExpenseById(id)
    }

    suspend fun getExpenseWithItemsById(id: Int): ExpenseWithItems? {
        return repository.getExpenseWithItemsById(id)
    }
}

class ExpenseViewModelFactory(private val repository: ExpenseRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ExpenseViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return ExpenseViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}