package com.example.misuperagenda.data.repository

import com.example.misuperagenda.data.database.EventDao
import com.example.misuperagenda.data.model.Event
import kotlinx.coroutines.flow.Flow
import java.time.LocalDateTime

/**
 * Repositorio que maneja la lógica de datos y la fuente única (Room en este caso).
 */
class EventRepository(private val eventDao: EventDao) {

    // 1. READ: Obtener todos los eventos, ordenados por fecha de inicio.
    val allEvents: Flow<List<Event>> = eventDao.getAllEvents()

    /**
     * 2. CREATE/UPDATE: Inserta o actualiza un evento.
     * Incluye la lógica de validación de solapamiento para eventos que no son Alarmas.
     * @return El ID del evento insertado, o -1 si hubo un solapamiento no permitido.
     */
    suspend fun insertOrUpdateEvent(event: Event): Long {

        // No verificamos solapamiento para Alarmas
        if (event.isOverlapExempt) {
            return eventDao.insert(event)
        }

        // Verificar solapamiento para eventos
        val eventIdToCheck = if (event.id == 0) -1 else event.id // Si es nuevo (id=0), usamos -1 para excluir

        val overlappingEvents = eventDao.findOverlappingEvents(
            eventId = eventIdToCheck,
            newStartTime = event.startTime,
            newEndTime = event.endTime
        )

        if (overlappingEvents.isNotEmpty()) {
            // Existe un solapamiento con otro evento (que no es Alarma)
            // Retornamos un valor especial para indicar el error
            return -1L
        }

        // No hay solapamiento, proceder con la inserción/actualización
        return eventDao.insert(event)
    }

    // 3. DELETE: Elimina un evento.
    suspend fun deleteEvent(event: Event) {
        eventDao.delete(event)
    }

    // 4. READ: Obtener un evento por su ID.
    suspend fun getEventById(id: Int): Event? {
        return eventDao.getEventById(id)
    }

    // 5. READ: Obtener eventos filtrados por categoría (usado por el ViewModel/UI).
    fun getEventsByCategory(category: String): Flow<List<Event>> {
        return eventDao.getEventsByCategory(category)
    }
}