package com.example.misuperagenda.data.repository

import com.example.misuperagenda.data.database.FinancialAccountDao
import com.example.misuperagenda.data.database.ExpenseDao
import com.example.misuperagenda.data.model.Expense
import com.example.misuperagenda.data.model.ExpenseStatus
import kotlinx.coroutines.flow.Flow
import com.example.misuperagenda.data.database.ExpenseItemDao
import com.example.misuperagenda.data.model.ExpenseWithItems

class ExpenseRepository(
    private val expenseDao: ExpenseDao,
    private val financialAccountDao: FinancialAccountDao,
    private val expenseItemDao: ExpenseItemDao
) {
    val allExpenses: Flow<List<Expense>> = expenseDao.getAllExpenses()

    suspend fun insertOrUpdateExpenseWithItems(expenseWithItems: ExpenseWithItems) {
        val expense = expenseWithItems.expense
        val items = expenseWithItems.items

        val originalExpense = if (expense.id != 0) expenseDao.getExpenseById(expense.id) else null

        // 1. Revertir cambios si el egreso original ya se había aplicado
        if (originalExpense != null && originalExpense.balanceApplied) {
            val account = financialAccountDao.getAccountById(originalExpense.accountId)
            if (account != null) {
                val newBalance = account.balance + originalExpense.realAmount
                financialAccountDao.update(account.copy(balance = newBalance))
            }
        }

        // ✅ CALCULAR TOTALES AUTOMÁTICAMENTE DE LOS ITEMS
        val calculatedBudgetedAmount = items.sumOf { it.quantity * it.presupuestadoPrice }
        val calculatedRealAmount = items.sumOf { it.quantity * it.unitPrice }

        val shouldApply = expense.expenseStatus == ExpenseStatus.EJECUTADO

        // ✅ USAR LOS TOTALES CALCULADOS AUTOMÁTICAMENTE
        val expenseToSave = expense.copy(
            budgetedAmount = calculatedBudgetedAmount,
            realAmount = calculatedRealAmount,
            balanceApplied = shouldApply
        )

        // Insertar/Actualizar el egreso principal y obtener su ID
        val expenseId: Int = expenseDao.insert(expenseToSave).toInt()

        // 2. Limpiar ítems viejos si es una actualización
        expenseItemDao.deleteItemsForExpense(expenseId)

        // 3. Insertar los nuevos ítems
        val itemsToSave = items.map { item ->
            item.copy(expenseId = expenseId)
        }
        expenseItemDao.insertAll(itemsToSave)

        // 4. Aplicar cambios al balance si es necesario
        if (shouldApply) {
            val account = financialAccountDao.getAccountById(expense.accountId)
            if (account != null) {
                val newBalance = account.balance - calculatedRealAmount
                financialAccountDao.update(account.copy(balance = newBalance))
            }
        }
    }

    suspend fun deleteExpense(expense: Expense) {
        if (expense.balanceApplied) {
            val account = financialAccountDao.getAccountById(expense.accountId)
            if (account != null) {
                val newBalance = account.balance + expense.realAmount
                financialAccountDao.update(account.copy(balance = newBalance))
            }
        }
        expenseDao.delete(expense)
    }

    suspend fun getExpenseById(id: Int): Expense? {
        return expenseDao.getExpenseById(id)
    }

    suspend fun getExpenseWithItemsById(id: Int): ExpenseWithItems? {
        return expenseDao.getExpenseWithItemsById(id)
    }
}