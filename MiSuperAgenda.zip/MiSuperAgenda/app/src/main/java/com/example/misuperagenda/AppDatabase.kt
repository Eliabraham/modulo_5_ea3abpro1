package com.example.misuperagenda.data.database
import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.misuperagenda.data.model.Event
import com.example.misuperagenda.data.model.FinancialAccount
import com.example.misuperagenda.data.model.Income
import com.example.misuperagenda.data.model.Expense
import com.example.misuperagenda.data.model.ExpenseItem
@Database(entities = [Event::class, FinancialAccount::class, Income::class, Expense::class,ExpenseItem::class], version = 7, exportSchema = false)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun eventDao(): EventDao
    abstract fun financialAccountDao(): FinancialAccountDao
    abstract fun incomeDao(): IncomeDao
    abstract fun expenseDao(): ExpenseDao
    abstract fun expenseItemDao(): ExpenseItemDao
    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null
        fun getDatabase(context: android.content.Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = androidx.room.Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "MiSuperAgenda_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}