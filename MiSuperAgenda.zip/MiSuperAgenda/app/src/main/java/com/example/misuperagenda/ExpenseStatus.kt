package com.example.misuperagenda.data.model
enum class ExpenseStatus {
    PLANIFICADO, // Gasto planeado o pendiente de liquidación
    EJECUTADO             // Gasto liquidado, el monto real afectará el saldo
}