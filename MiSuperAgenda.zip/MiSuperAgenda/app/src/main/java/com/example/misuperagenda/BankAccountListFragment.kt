package com.example.misuperagenda.ui.fragments

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.misuperagenda.data.database.AppDatabase
import com.example.misuperagenda.data.model.FinancialAccount
import com.example.misuperagenda.data.repository.FinancialAccountRepository
import com.example.misuperagenda.databinding.FragmentBankAccountListBinding
import com.example.misuperagenda.ui.FinancialAccountDetailActivity
import com.example.misuperagenda.ui.adapter.FinancialAccountAdapter
import com.example.misuperagenda.ui.viewmodel.FinancialAccountViewModel
import com.example.misuperagenda.ui.viewmodel.FinancialAccountViewModelFactory
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

class BankAccountListFragment : Fragment() {
    private var _binding: FragmentBankAccountListBinding? = null
    private val binding get() = _binding!!

    private val financialAccountViewModel: FinancialAccountViewModel by activityViewModels {
        val database = AppDatabase.getDatabase(requireContext())
        val repository = FinancialAccountRepository(database.financialAccountDao())
        FinancialAccountViewModelFactory(repository)
    }

    private lateinit var adapter: FinancialAccountAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentBankAccountListBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecyclerView()
        observeAccounts()
        setupFab()
    }

    private fun setupRecyclerView() {
        adapter = FinancialAccountAdapter(
            onItemClick = { account ->
                // Abrir edición al hacer clic normal en el item
                val intent = FinancialAccountDetailActivity.newIntent(requireContext(), account.id)
                startActivity(intent)
            },
            onItemLongClick = { account ->
                // Mostrar menú contextual al hacer clic largo
                showContextMenu(account)
                true
            },
            onDeleteClick = { account ->
                // Eliminar directamente al hacer clic en el botón de eliminar
                showDeleteConfirmationDialog(account)
            }
        )
        binding.recyclerViewAccounts.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = this@BankAccountListFragment.adapter
        }
    }

    private fun showContextMenu(account: FinancialAccount) {
        val options = arrayOf("Editar", "Eliminar")

        AlertDialog.Builder(requireContext())
            .setTitle("${account.institution} - ${account.accountNumber}")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> {
                        // Editar
                        val intent = FinancialAccountDetailActivity.newIntent(requireContext(), account.id)
                        startActivity(intent)
                    }
                    1 -> {
                        // Eliminar
                        showDeleteConfirmationDialog(account)
                    }
                }
            }
            .show()
    }

    private fun showDeleteConfirmationDialog(account: FinancialAccount) {
        AlertDialog.Builder(requireContext())
            .setTitle("Confirmar Eliminación")
            .setMessage("¿Estás seguro de que quieres eliminar la cuenta ${account.accountNumber} de ${account.institution}?")
            .setPositiveButton("Eliminar") { dialog, _ ->
                lifecycleScope.launch {
                    try {
                        financialAccountViewModel.delete(account)
                        // El mensaje se mostrará automáticamente cuando la lista se actualice
                    } catch (e: Exception) {
                        // Mostrar error si falla
                        android.widget.Toast.makeText(requireContext(), "Error al eliminar: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
                    }
                }
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }

    private fun observeAccounts() {
        viewLifecycleOwner.lifecycleScope.launch {
            financialAccountViewModel.allAccounts.collect { accounts ->
                println("DEBUG: Número de cuentas observadas: ${accounts.size}")
                adapter.submitList(accounts)

                // Calcular total general
                val total = accounts.sumOf { it.balance }
                binding.textTotal.text = "Total General: $${String.format("%.2f", total)}"

                // Mostrar/ocultar mensaje de vacío
                if (accounts.isEmpty()) {
                    binding.textEmptyState.visibility = View.VISIBLE
                    binding.recyclerViewAccounts.visibility = View.GONE
                    binding.textTotal.visibility = View.GONE
                } else {
                    binding.textEmptyState.visibility = View.GONE
                    binding.recyclerViewAccounts.visibility = View.VISIBLE
                    binding.textTotal.visibility = View.VISIBLE
                }
            }
        }
    }

    private fun setupFab() {
        binding.fabAddAccount.setOnClickListener {
            val intent = Intent(requireContext(), FinancialAccountDetailActivity::class.java)
            startActivity(intent)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}