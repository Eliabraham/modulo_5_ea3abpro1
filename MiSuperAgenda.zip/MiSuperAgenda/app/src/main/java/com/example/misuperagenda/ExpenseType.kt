package com.example.misuperagenda.data.model
enum class ExpenseType {
    HOGAR,
    EDUCACION,
    SALUD,
    ALIMENTACION,
    TRANSPORTE,
    INVERSION,
    ESPARCIMIENTO,
    FAMILIA
}