package com.example.misuperagenda.ui.adapter

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.misuperagenda.data.model.Categoria
import com.example.misuperagenda.data.model.Estado // NUEVO: Importación del enum Estado
import com.example.misuperagenda.data.model.Event
import com.example.misuperagenda.databinding.ItemEventBinding
import java.time.format.DateTimeFormatter

class EventAdapter(private val onItemClick: (Event) -> Unit) :
    ListAdapter<Event, EventAdapter.EventViewHolder>(EventDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EventViewHolder {
        val binding = ItemEventBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return EventViewHolder(binding)
    }

    override fun onBindViewHolder(holder: EventViewHolder, position: Int) {
        holder.bind(getItem(position), onItemClick)
    }

    class EventViewHolder(private val binding: ItemEventBinding) :
        RecyclerView.ViewHolder(binding.root) {

        private val timeFormatter = DateTimeFormatter.ofPattern("HH:mm")
        private val dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")

        fun bind(event: Event, onItemClick: (Event) -> Unit) {
            binding.textTitle.text = event.title
            val dateString = event.startTime.format(dateFormatter)
            val timeStart = event.startTime.format(timeFormatter)
            val timeEnd = event.endTime.format(timeFormatter)
            binding.textTime.text = "$dateString | $timeStart - $timeEnd"

            // Verifica y muestra la ubicación o descripción (manteniendo tu lógica)
            binding.textLocation.text = event.locationName ?: event.description

            // Muestra la barra lateral con el color de la categoría
            binding.categoryIndicator.setBackgroundColor(getCategoryColor(event.category))

            // LÓGICA PARA MOSTRAR MÚLTIPLES INVITADOS
            if (event.guests.isNullOrEmpty()) {
                binding.textEventGuests.visibility = View.GONE
            } else {
                binding.textEventGuests.visibility = View.VISIBLE
                val guestsString = event.guests.joinToString(separator = ", ")
                binding.textEventGuests.text = "Invitados: $guestsString"
            }

            // LÓGICA PARA MOSTRAR EL ESTADO (NUEVO)
            // 1. Mostrar el texto del estado (PENDIENTE, COMPLETADO, etc.)
            binding.textStatus.text = event.estado.name

            // 2. Aplicar el color basado en el estado
            binding.textStatus.setTextColor(getStateColor(event.estado))


            binding.root.setOnClickListener {
                onItemClick(event)
            }
        }
        /**
         * Devuelve el color hexadecimal para la categoría.
         */
        private fun getCategoryColor(category: Categoria): Int {
            return when (category) {
                // Adaptado a tus categorías existentes
                Categoria.FAMILIA -> Color.parseColor("#4CAF50")
                Categoria.TRABAJO -> Color.parseColor("#2196F3")
                Categoria.ESPARCIMIENTO -> Color.parseColor("#FFC107")
                Categoria.ROMANCE -> Color.parseColor("#E91E63")
                Categoria.ALARMA -> Color.parseColor("#F44336")
                Categoria.OTRO -> Color.parseColor("#9E9E9E")
                // Se agregó 'else' para evitar errores de compilación si existen más categorías en el enum Categoria
                else -> Color.parseColor("#000000") // Color por defecto
            }
        }

        /**
         * Devuelve el color hexadecimal para el estado de la tarea. (NUEVO)
         */
        private fun getStateColor(estado: Estado): Int {
            return when (estado) {
                Estado.PENDIENTE -> Color.parseColor("#FFC107")       // Amarillo: Pendiente
                Estado.EN_PROCESO -> Color.parseColor("#03A9F4")      // Azul: En Proceso
                Estado.PAUSADO -> Color.parseColor("#9C27B0")         // Morado: Pausado
                Estado.CANCELADO -> Color.parseColor("#F44336")       // Rojo: Cancelado
                Estado.COMPLETADO -> Color.parseColor("#4CAF50")      // Verde: Completado
            }
        }
    }
}

class EventDiffCallback : DiffUtil.ItemCallback<Event>() {
    override fun areItemsTheSame(oldItem: Event, newItem: Event): Boolean {
        return oldItem.id == newItem.id
    }

    // MÉTODO CORREGIDO: ahora compara los contenidos.
    override fun areContentsTheSame(oldItem: Event, newItem: Event): Boolean {
        return oldItem == newItem
    }
}