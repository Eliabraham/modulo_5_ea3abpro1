package com.example.misuperagenda.ui.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.misuperagenda.data.model.FinancialAccount
import com.example.misuperagenda.databinding.ItemFinancialAccountBinding

class FinancialAccountAdapter(
    private val onItemClick: (FinancialAccount) -> Unit = {},
    private val onItemLongClick: (FinancialAccount) -> Boolean = { false },
    private val onDeleteClick: (FinancialAccount) -> Unit = {}  // Nuevo parámetro para eliminar
) : ListAdapter<FinancialAccount, FinancialAccountAdapter.FinancialAccountViewHolder>(
    FinancialAccountDiffCallback()
) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FinancialAccountViewHolder {
        val binding = ItemFinancialAccountBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return FinancialAccountViewHolder(binding, onItemClick, onItemLongClick, onDeleteClick)
    }

    override fun onBindViewHolder(holder: FinancialAccountViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class FinancialAccountViewHolder(
        private val binding: ItemFinancialAccountBinding,
        private val onItemClick: (FinancialAccount) -> Unit,
        private val onItemLongClick: (FinancialAccount) -> Boolean,
        private val onDeleteClick: (FinancialAccount) -> Unit  // Nuevo parámetro
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(account: FinancialAccount) {
            binding.textInstitution.text = account.institution
            binding.textAccountNumber.text = account.accountNumber
            binding.textAccountType.text = account.accountType
            binding.textBalance.text = "$${String.format("%.2f", account.balance)}"
            binding.textCurrency.text = account.currency

            account.description?.let {
                binding.textDescription.text = it
                binding.textDescription.visibility = View.VISIBLE
            } ?: run {
                binding.textDescription.visibility = View.GONE
            }

            // Clic en el item completo - para editar
            binding.root.setOnClickListener {
                onItemClick(account)
            }

            // Clic largo en el item completo - menú contextual
            binding.root.setOnLongClickListener {
                onItemLongClick(account)
            }

            // Clic en el botón eliminar
            binding.buttonDelete.setOnClickListener {
                onDeleteClick(account)
            }
        }
    }
}

class FinancialAccountDiffCallback : DiffUtil.ItemCallback<FinancialAccount>() {
    override fun areItemsTheSame(oldItem: FinancialAccount, newItem: FinancialAccount): Boolean {
        return oldItem.id == newItem.id
    }

    override fun areContentsTheSame(oldItem: FinancialAccount, newItem: FinancialAccount): Boolean {
        return oldItem == newItem
    }
}