package com.example.misuperagenda.data.model
import androidx.room.Embedded
import androidx.room.Relation

// Clase para encapsular la relación 1-a-Muchos
data class ExpenseWithItems(
    @Embedded val expense: Expense, // El egreso principal
    @Relation(
        parentColumn = "id",
        entityColumn = "expenseId"
    )
    val items: List<ExpenseItem> // La lista de detalles/items
)