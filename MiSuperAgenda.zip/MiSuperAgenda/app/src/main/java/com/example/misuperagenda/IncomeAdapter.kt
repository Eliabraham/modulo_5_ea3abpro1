package com.example.misuperagenda.ui.adapter

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.misuperagenda.R
import com.example.misuperagenda.data.model.Income
import com.example.misuperagenda.data.model.IncomeStatus
import com.example.misuperagenda.databinding.ItemIncomeBinding
import com.example.misuperagenda.ui.viewmodel.FinancialAccountViewModel
import com.example.misuperagenda.ui.fragments.IncomeListFragment // Necesario para el scope
import kotlinx.coroutines.launch
import java.time.format.DateTimeFormatter


class IncomeAdapter(
    private val onItemClick: (Income) -> Unit,
    private val financialAccountViewModel: FinancialAccountViewModel,
    private val lifecycleOwner: LifecycleOwner
) : ListAdapter<Income, IncomeAdapter.IncomeViewHolder>(IncomeDiffCallback()) {
    /*override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): IncomeViewHolder {
        val binding = ItemIncomeBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return IncomeViewHolder(binding, onItemClick, financialAccountViewModel)
    }*/

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): IncomeViewHolder {
        val binding = ItemIncomeBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        // PASS the lifecycleOwner here
        return IncomeViewHolder(binding, onItemClick, financialAccountViewModel, lifecycleOwner)
    }

    override fun onBindViewHolder(holder: IncomeViewHolder, position: Int) {
        holder.bind(getItem(position))
    }
    class IncomeViewHolder(
        private val binding: ItemIncomeBinding,
        private val onItemClick: (Income) -> Unit,
        private val financialAccountViewModel: FinancialAccountViewModel,

        private val lifecycleOwner: LifecycleOwner

    ) : RecyclerView.ViewHolder(binding.root) {
        private val dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")
        fun bind(income: Income) {
            binding.textIncomeTitle.text = income.title
            binding.textIncomeType.text = "Tipo: ${income.type.name}"
            binding.textIncomeStatus.text = income.status.name
            if (income.status == IncomeStatus.POR_COBRAR) {
                binding.textIncomeStatus.setBackgroundResource(R.drawable.rounded_background_pending)
                binding.textIncomeStatus.setTextColor(Color.parseColor("#FFB300")) // Color del borde
            } else {
                binding.textIncomeStatus.setBackgroundColor(Color.parseColor("#4CAF50"))
                binding.textIncomeStatus.setTextColor(Color.WHITE)
            }
           /* binding.root.context.lifecycleScope.launch {
                val account = financialAccountViewModel.getAccountByIdFromDb(income.accountId)
                val accountName = account?.institution ?: "Cuenta Eliminada"
                val currency = account?.currency ?: ""
                binding.textIncomeAmount.text = "+ $${String.format("%.2f", income.amount)} ${currency}"
                binding.textIncomeAccountAndDate.text =
                    "$accountName | ${income.incomeDate.format(dateFormatter)}"
            }*/
            lifecycleOwner.lifecycleScope.launch {
                val account = financialAccountViewModel.getAccountByIdFromDb(income.accountId)
                val accountName = account?.institution ?: "Cuenta Eliminada"
                val currency = account?.currency ?: ""
                binding.textIncomeAmount.text = "+ $${String.format("%.2f", income.amount)} ${currency}"
                binding.textIncomeAccountAndDate.text =
                    "$accountName | ${income.incomeDate.format(dateFormatter)}"
            }
            binding.root.setOnClickListener {
                onItemClick(income)
            }
        }
    }
}

class IncomeDiffCallback : DiffUtil.ItemCallback<Income>() {
    override fun areItemsTheSame(oldItem: Income, newItem: Income): Boolean {
        return oldItem.id == newItem.id
    }

    override fun areContentsTheSame(oldItem: Income, newItem: Income): Boolean {
        // Incluir 'hasAppliedToBalance' en la comparación para que se actualice la vista
        return oldItem == newItem
    }
}