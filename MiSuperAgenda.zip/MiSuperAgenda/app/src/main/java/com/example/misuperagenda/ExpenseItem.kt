package com.example.misuperagenda.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.ForeignKey
import androidx.room.Index

/**
 * Room Entity for an item/detail within an Expense.
 */
@Entity(
    tableName = "expense_items", // Nombre de tabla en PLURAL y en inglés
    foreignKeys = [
        ForeignKey(
            entity = Expense::class,
            parentColumns = ["id"],
            childColumns = ["expenseId"], // Clave foránea que referencia al Expense
            onDelete = ForeignKey.CASCADE // Si se elimina el Expense, se eliminan sus ítems
        )
    ],
    indices = [Index("expenseId")] // Indice en la clave foránea
)
data class ExpenseItem(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val expenseId: Int, // <-- CLAVE FORÁNEA al Expense
    val detail: String, // Descripción del ítem (e.g., "Leche entera", "Luz eléctrica")
    val quantity: Double = 1.0, // Cantidad (e.g., 2.0 kg, 3.0 unidades, 1.0 factura)
    val unitPrice: Double,      // Precio unitario
    val presupuestadoPrice: Double ,
    val itemAmount: Double      // Monto total del ítem (quantity * unitPrice)
)