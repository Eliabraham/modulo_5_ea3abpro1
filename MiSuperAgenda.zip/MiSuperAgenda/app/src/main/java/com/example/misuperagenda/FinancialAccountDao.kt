package com.example.misuperagenda.data.database
import androidx.room.*
import com.example.misuperagenda.data.model.FinancialAccount
import kotlinx.coroutines.flow.Flow
@Dao
interface FinancialAccountDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(account: FinancialAccount): Long
    @Update
    suspend fun update(account: FinancialAccount)
    @Delete
    suspend fun delete(account: FinancialAccount)
    @Query("SELECT * FROM financial_accounts ORDER BY institution, accountType")
    fun getAllAccounts(): Flow<List<FinancialAccount>>
    @Query("SELECT * FROM financial_accounts WHERE id = :id")
    suspend fun getAccountById(id: Int): FinancialAccount?
    @Query("SELECT DISTINCT institution FROM financial_accounts WHERE isActive = 1 ORDER BY institution")
    fun getInstitutions(): Flow<List<String>>
    @Query("SELECT * FROM financial_accounts WHERE institution = :institution ORDER BY accountType")
    fun getAccountsByInstitution(institution: String): Flow<List<FinancialAccount>>
    /*@Query("SELECT * FROM financial_accounts WHERE id = :id")
    suspend fun getEventById(id: Int): FinancialAccount?*/
}