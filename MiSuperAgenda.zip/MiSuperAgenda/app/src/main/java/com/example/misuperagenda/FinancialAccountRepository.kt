package com.example.misuperagenda.data.repository
import com.example.misuperagenda.data.database.FinancialAccountDao
import com.example.misuperagenda.data.model.FinancialAccount
import kotlinx.coroutines.flow.Flow
/*class FinancialAccountRepository(private val financialAccountDao: FinancialAccountDao) {
    val allAccounts: Flow<List<FinancialAccount>> = financialAccountDao.getAllAccounts()
    val institutions: Flow<List<String>> = financialAccountDao.getInstitutions()
    suspend fun insertAccount(account: FinancialAccount): Long {
        return financialAccountDao.insert(account)
    }
    suspend fun updateAccount(account: FinancialAccount) {
        financialAccountDao.update(account)
    }
    suspend fun deleteAccount(account: FinancialAccount) {
        financialAccountDao.delete(account)
    }
    suspend fun getAccountById(id: Int): FinancialAccount? {
        return financialAccountDao.getAccountById(id)
    }
    fun getAccountsByInstitution(institution: String): Flow<List<FinancialAccount>> {
        return financialAccountDao.getAccountsByInstitution(institution)
    }
    /*suspend fun deleteEvent(event: Event) {
        eventDao.delete(event)
    }*/
}*/

class FinancialAccountRepository(private val financialAccountDao: FinancialAccountDao) {

    val allAccounts: Flow<List<FinancialAccount>> = financialAccountDao.getAllAccounts()

    val institutions: Flow<List<String>> = financialAccountDao.getInstitutions()

    suspend fun insertAccount(account: FinancialAccount): Long {
        return financialAccountDao.insert(account)
    }

    suspend fun updateAccount(account: FinancialAccount) {
        financialAccountDao.update(account)
    }

    suspend fun deleteAccount(account: FinancialAccount) {
        financialAccountDao.delete(account)
    }

    suspend fun getAccountById(id: Int): FinancialAccount? {
        return financialAccountDao.getAccountById(id)
    }

    fun getAccountsByInstitution(institution: String): Flow<List<FinancialAccount>> {
        return financialAccountDao.getAccountsByInstitution(institution)
    }
}