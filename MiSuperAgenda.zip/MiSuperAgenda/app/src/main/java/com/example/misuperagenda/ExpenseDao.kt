package com.example.misuperagenda.data.database

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction

import androidx.room.Update
import com.example.misuperagenda.data.model.Expense
import com.example.misuperagenda.data.model.ExpenseWithItems
import kotlinx.coroutines.flow.Flow

@Dao
interface ExpenseDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(expense: Expense): Long

    @Update
    suspend fun update(expense: Expense)

    @Delete
    suspend fun delete(expense: Expense)

    @Query("SELECT * FROM expenses ORDER BY expenseDate DESC")
    fun getAllExpenses(): Flow<List<Expense>>

    @Query("SELECT * FROM expenses WHERE id = :id")
    suspend fun getExpenseById(id: Int): Expense?

    @Query("SELECT * FROM expenses WHERE accountId = :accountId ORDER BY expenseDate DESC")
    fun getExpensesByAccountId(accountId: Int): Flow<List<Expense>>

    @Transaction
    @Query("SELECT * FROM expenses ORDER BY expenseDate DESC")
    fun getAllExpensesWithItems(): Flow<List<ExpenseWithItems>> // <-- NUEVA FUNCIÓN

    @Transaction
    @Query("SELECT * FROM expenses WHERE id = :id")
    suspend fun getExpenseWithItemsById(id: Int): ExpenseWithItems? // <-- NUEVA FUNCIÓN
}