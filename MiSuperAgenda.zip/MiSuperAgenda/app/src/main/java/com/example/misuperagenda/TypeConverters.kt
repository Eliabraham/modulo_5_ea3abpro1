package com.example.misuperagenda.data.database

import androidx.room.TypeConverter
import com.example.misuperagenda.data.model.Categoria
import com.example.misuperagenda.data.model.Estado
import com.example.misuperagenda.data.model.IncomeType
import com.example.misuperagenda.data.model.IncomeStatus
import com.example.misuperagenda.data.model.ExpenseType
import com.example.misuperagenda.data.model.ExpenseStatus
import java.time.LocalDateTime
import java.time.ZoneOffset

class Converters {
    // Conversión de LocalDateTime a Long (Timestamp)
    @TypeConverter
    fun fromTimestamp(value: Long?): LocalDateTime? {
        return value?.let {
            LocalDateTime.ofEpochSecond(it / 1000, 0, ZoneOffset.UTC)
        }
    }

    @TypeConverter
    fun dateToTimestamp(date: LocalDateTime?): Long? {
        return date?.atZone(ZoneOffset.UTC)?.toInstant()?.toEpochMilli()
    }

    // --- Conversiones para IncomeType (Añadida la anotación faltante) ---
    @TypeConverter
    fun fromIncomeType(type: IncomeType): String {
        return type.name
    }

    @TypeConverter
    fun toIncomeType(typeString: String): IncomeType {
        return IncomeType.valueOf(typeString)
    }

    // --- Conversiones para IncomeStatus ---
    @TypeConverter
    fun fromIncomeStatus(status: IncomeStatus): String {
        return status.name
    }

    @TypeConverter
    fun toIncomeStatus(statusString: String): IncomeStatus {
        return IncomeStatus.valueOf(statusString)
    }

    // --------------------------------------------------------------------------
    // CONVERSIONES PARA EXPENSE (EGRESO)
    // --------------------------------------------------------------------------

    // --- Conversiones para ExpenseType (NUEVAS) ---
    @TypeConverter
    fun fromExpenseType(type: ExpenseType): String {
        return type.name
    }

    @TypeConverter
    fun toExpenseType(typeString: String): ExpenseType {
        return ExpenseType.valueOf(typeString)
    }

    // --- Conversiones para ExpenseStatus (NUEVAS) ---
    @TypeConverter
    fun fromExpenseStatus(status: ExpenseStatus): String {
        return status.name
    }

    @TypeConverter
    fun toExpenseStatus(statusString: String): ExpenseStatus {
        return ExpenseStatus.valueOf(statusString)
    }

    // --- Conversiones para Categoria ---
    @TypeConverter
    fun fromCategoria(categoria: Categoria): String {
        return categoria.name
    }

    @TypeConverter
    fun toCategoria(categoriaString: String): Categoria {
        return Categoria.valueOf(categoriaString)
    }

    // --- Conversiones para Estado (Asumiendo que es necesario) ---
    @TypeConverter
    fun fromEstado(estado: Estado): String {
        return estado.name
    }

    @TypeConverter
    fun toEstado(estadoString: String): Estado {
        return Estado.valueOf(estadoString)
    }

    // Conversión de List<String>
    @TypeConverter
    fun fromListString(list: List<String>?): String? {
        return list?.joinToString(",")
    }

    @TypeConverter
    fun toListString(data: String?): List<String>? {
        return data?.split(",")?.map { it.trim() }?.filter { it.isNotEmpty() }
    }
}