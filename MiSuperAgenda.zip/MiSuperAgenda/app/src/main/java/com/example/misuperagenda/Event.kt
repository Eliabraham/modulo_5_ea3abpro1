package com.example.misuperagenda.data.model
import androidx.room.Entity
import androidx.room.PrimaryKey
import java.time.LocalDateTime
@Entity(tableName = "events")
data class Event(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val title: String,
    val description: String,
    val category: Categoria,
    val estado: Estado,
    val startTime: LocalDateTime,
    val endTime: LocalDateTime,
    val locationName: String? = null,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val guests: List<String>? = null,
    val notes: String? = null,
    val comments: String? = null,
    val isRepeating: Boolean = false,
    val repeatType: String? = null,
    val repeatDaysOfWeek: String? = null,
    val repeatEndDate: LocalDateTime? = null,
    val ringtoneUri: String? = null
){
    val isOverlapExempt: Boolean
        get() = category == Categoria.ALARMA
}