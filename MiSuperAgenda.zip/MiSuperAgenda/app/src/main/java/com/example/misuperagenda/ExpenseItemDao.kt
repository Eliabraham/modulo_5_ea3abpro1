package com.example.misuperagenda.data.database

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.misuperagenda.data.model.ExpenseItem
import kotlinx.coroutines.flow.Flow

@Dao
interface ExpenseItemDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: ExpenseItem)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<ExpenseItem>)

    @Update
    suspend fun update(item: ExpenseItem)

    @Delete
    suspend fun delete(item: ExpenseItem)

    @Query("SELECT * FROM expense_items WHERE expenseId = :expenseId ORDER BY id ASC")
    fun getItemsForExpense(expenseId: Int): Flow<List<ExpenseItem>>

    @Query("DELETE FROM expense_items WHERE expenseId = :expenseId")
    suspend fun deleteItemsForExpense(expenseId: Int)
}