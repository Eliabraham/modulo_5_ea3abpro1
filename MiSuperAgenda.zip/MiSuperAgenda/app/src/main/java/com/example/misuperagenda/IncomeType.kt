package com.example.misuperagenda.data.model

enum class IncomeType {
    SUELDO,
    VENTA,
    BONO_GUBERNAMENTAL,
    AGUINALDO,
    OTRO
}