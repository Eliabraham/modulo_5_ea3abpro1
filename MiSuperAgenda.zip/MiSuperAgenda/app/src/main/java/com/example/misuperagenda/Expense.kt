package com.example.misuperagenda.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.ForeignKey
import androidx.room.Index
import java.time.LocalDateTime

@Entity(
    tableName = "expenses",
    foreignKeys = [
        ForeignKey(
            entity = FinancialAccount::class,
            parentColumns = ["id"],
            childColumns = ["accountId"],
            onDelete = ForeignKey.RESTRICT
        )
    ],
    indices = [Index("accountId")]
)
data class Expense(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val title: String,
    val expenseDate: LocalDateTime,
    val accountId: Int,
    val description: String,
    val budgetedAmount: Double,
    val realAmount: Double,
    val expenseType: ExpenseType,
    val expenseStatus: ExpenseStatus,
    val balanceApplied: Boolean = false,
    val experience: ExpenseExperience? = null
)