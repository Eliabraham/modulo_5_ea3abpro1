package com.example.misuperagenda.ui

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.misuperagenda.R
import com.example.misuperagenda.data.database.AppDatabase
import com.example.misuperagenda.data.model.FinancialAccount
import com.example.misuperagenda.data.repository.FinancialAccountRepository
import com.example.misuperagenda.databinding.ActivityFinancialAccountDetailBinding
import com.example.misuperagenda.ui.viewmodel.FinancialAccountViewModel
import com.example.misuperagenda.ui.viewmodel.FinancialAccountViewModelFactory
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.launch

class FinancialAccountDetailActivity : AppCompatActivity() {
    private lateinit var binding: ActivityFinancialAccountDetailBinding

    private lateinit var textDetailTitle: android.widget.TextView
    private lateinit var editInstitution: TextInputEditText
    private lateinit var editAccountNumber: TextInputEditText
    private lateinit var editAccountType: TextInputEditText
    private lateinit var editBalance: TextInputEditText
    private lateinit var editCurrency: TextInputEditText
    private lateinit var editDescription: TextInputEditText
    private lateinit var buttonDelete: Button
    private lateinit var buttonSave: Button

    private val financialAccountViewModel: FinancialAccountViewModel by viewModels {
        val database = AppDatabase.getDatabase(applicationContext)
        val repository = FinancialAccountRepository(database.financialAccountDao())
        FinancialAccountViewModelFactory(repository)
    }

    private var accountId: Int? = null
    private var currentAccount: FinancialAccount? = null

    companion object {
        const val EXTRA_ACCOUNT_ID = "account_id"
        fun newIntent(context: android.content.Context, accountId: Int? = null): Intent {
            return Intent(context, FinancialAccountDetailActivity::class.java).apply {
                accountId?.let { putExtra(EXTRA_ACCOUNT_ID, it) }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFinancialAccountDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setResult(Activity.RESULT_CANCELED)

        initViews()
        setupSaveButton()
        setupDeleteButton()

        accountId = intent.getIntExtra(EXTRA_ACCOUNT_ID, -1).takeIf { it != -1 }
        accountId?.let { loadAccountDetails(it) } ?: setupNewAccountDefaults()
    }

    private fun initViews() {
        textDetailTitle = binding.textDetailTitle
        editInstitution = binding.editInstitution
        editAccountNumber = binding.editAccountNumber
        editAccountType = binding.editAccountType
        editBalance = binding.editBalance
        editCurrency = binding.editCurrency
        editDescription = binding.editDescription
        buttonDelete = binding.buttonDelete
        buttonSave = binding.buttonSave
    }

    private fun setupNewAccountDefaults() {
        textDetailTitle.text = "Nueva Cuenta"
        buttonDelete.visibility = android.view.View.GONE
    }

    /*private fun loadAccountDetails(id: Int) {
        textDetailTitle.text = "Editar Cuenta"
        buttonDelete.visibility = android.view.View.VISIBLE
        // Usar lifecycleScope para la corrutina
        lifecycleScope.launch {
            // Buscar la cuenta en la lista actual
            val accounts = financialAccountViewModel.allAccounts.value
            currentAccount = accounts.find { it.id == id }
            currentAccount?.let { account ->
                editInstitution.setText(account.institution)
                editAccountNumber.setText(account.accountNumber)
                editAccountType.setText(account.accountType)
                editBalance.setText(account.balance.toString())
                editCurrency.setText(account.currency)
                editDescription.setText(account.description)
            } ?: run {
                Toast.makeText(this@FinancialAccountDetailActivity, "Cuenta no encontrada", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }*/

    private fun loadAccountDetails(id: Int) {
        textDetailTitle.text = "Editar Cuenta"
        buttonDelete.visibility = android.view.View.VISIBLE
        // Usar lifecycleScope para la corrutina
        lifecycleScope.launch {
            try {
                // Obtener la cuenta directamente del repositorio (base de datos)
                val account = financialAccountViewModel.getAccountByIdFromDb(id)
                currentAccount = account
                currentAccount?.let { account ->
                    editInstitution.setText(account.institution)
                    editAccountNumber.setText(account.accountNumber)
                    editAccountType.setText(account.accountType)
                    editBalance.setText(account.balance.toString())
                    editCurrency.setText(account.currency)
                    editDescription.setText(account.description)
                } ?: run {
                    Toast.makeText(this@FinancialAccountDetailActivity, "Cuenta no encontrada", Toast.LENGTH_SHORT).show()
                    finish()
                }
            } catch (e: Exception) {
                Toast.makeText(this@FinancialAccountDetailActivity, "Error al cargar la cuenta: ${e.message}", Toast.LENGTH_SHORT).show()
                finish()
            }
            // Buscar la cuenta usando el método del ViewModel
            /*currentAccount = financialAccountViewModel.getAccountById(id)
            currentAccount?.let { account ->
                editInstitution.setText(account.institution)
                editAccountNumber.setText(account.accountNumber)
                editAccountType.setText(account.accountType)
                editBalance.setText(account.balance.toString())
                editCurrency.setText(account.currency)
                editDescription.setText(account.description)
            } ?: run {
                Toast.makeText(this@FinancialAccountDetailActivity, "Cuenta no encontrada", Toast.LENGTH_SHORT).show()
                finish()
            }*/
        }
    }

    private fun setupSaveButton() {
        buttonSave.setOnClickListener {
            validateAndSaveAccount()
        }
    }

    private fun setupDeleteButton() {
        buttonDelete.setOnClickListener {
            showDeleteConfirmationDialog()
        }
    }

    private fun validateAndSaveAccount() {
        val institution = editInstitution.text.toString().trim()
        val accountNumber = editAccountNumber.text.toString().trim()
        val accountType = editAccountType.text.toString().trim()
        val balanceText = editBalance.text.toString().trim()
        val currency = editCurrency.text.toString().trim()
        val description = editDescription.text.toString().trim()

        var errorMessage: String? = null

        if (institution.isEmpty()) {
            errorMessage = "La institución es obligatoria."
        } else if (accountNumber.isEmpty()) {
            errorMessage = "El número de cuenta es obligatorio."
        } else if (accountType.isEmpty()) {
            errorMessage = "El tipo de cuenta es obligatorio."
        } else if (balanceText.isEmpty()) {
            errorMessage = "El saldo es obligatorio."
        }

        if (errorMessage != null) {
            AlertDialog.Builder(this)
                .setTitle("Campos Incompletos")
                .setMessage(errorMessage)
                .setPositiveButton("Aceptar") { dialog, _ -> dialog.dismiss() }
                .show()
            return
        }

        val balance = balanceText.toDoubleOrNull()
        if (balance == null) {
            AlertDialog.Builder(this)
                .setTitle("Error")
                .setMessage("El saldo debe ser un número válido.")
                .setPositiveButton("Aceptar") { dialog, _ -> dialog.dismiss() }
                .show()
            return
        }

        val accountToSave = currentAccount?.copy(
            institution = institution,
            accountNumber = accountNumber,
            accountType = accountType,
            balance = balance,
            currency = currency,
            description = description
        ) ?: FinancialAccount(
            institution = institution,
            accountNumber = accountNumber,
            accountType = accountType,
            balance = balance,
            currency = currency,
            description = description
        )

        financialAccountViewModel.insert(accountToSave)
        Toast.makeText(this, "Cuenta guardada exitosamente.", Toast.LENGTH_SHORT).show()
        setResult(Activity.RESULT_OK)
        finish()
    }

    private fun showDeleteConfirmationDialog() {
        AlertDialog.Builder(this)
            .setTitle("Confirmar Eliminación")
            .setMessage("¿Estás seguro de que quieres eliminar esta cuenta?")
            .setPositiveButton("Sí, Eliminar") { dialog, _ ->
                currentAccount?.let { account ->
                    financialAccountViewModel.delete(account)
                    Toast.makeText(this, "Cuenta eliminada.", Toast.LENGTH_SHORT).show()
                    setResult(Activity.RESULT_OK)
                    finish()
                }
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }
}























