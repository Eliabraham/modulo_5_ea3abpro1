package com.example.misuperagenda.data.model
enum class Categoria {
    FAMILIA,
    TRABAJO,
    ESPARCIMIENTO,
    ROMANCE,
    ALARMA,
    OTRO
}