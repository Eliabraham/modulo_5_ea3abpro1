/*package com.example.misuperagenda.data.database

import androidx.room.TypeConverter
import com.example.misuperagenda.data.model.*
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

class Converters {

    @TypeConverter
    fun fromTimestamp(value: String?): LocalDateTime? {
        return value?.let { LocalDateTime.parse(it, DateTimeFormatter.ISO_LOCAL_DATE_TIME) }
    }

    @TypeConverter
    fun dateToTimestamp(date: LocalDateTime?): String? {
        return date?.format(DateTimeFormatter.ISO_LOCAL_DATE_TIME)
    }

    @TypeConverter
    fun fromString(value: String?): List<String>? {
        return value?.split(",")?.map { it.trim() }
    }

    @TypeConverter
    fun toString(list: List<String>?): String? {
        return list?.joinToString(",")
    }

    // Enum converters
    @TypeConverter
    fun fromCategoria(value: String?): Categoria? = value?.let { Categoria.valueOf(it) }

    @TypeConverter
    fun categoriaToString(categoria: Categoria?): String? = categoria?.name

    @TypeConverter
    fun fromEstado(value: String?): Estado? = value?.let { Estado.valueOf(it) }

    @TypeConverter
    fun estadoToString(estado: Estado?): String? = estado?.name

    @TypeConverter
    fun fromExpenseType(value: String?): ExpenseType? = value?.let { ExpenseType.valueOf(it) }

    @TypeConverter
    fun expenseTypeToString(type: ExpenseType?): String? = type?.name

    @TypeConverter
    fun fromExpenseStatus(value: String?): ExpenseStatus? = value?.let { ExpenseStatus.valueOf(it) }

    @TypeConverter
    fun expenseStatusToString(status: ExpenseStatus?): String? = status?.name

    @TypeConverter
    fun fromIncomeType(value: String?): IncomeType? = value?.let { IncomeType.valueOf(it) }

    @TypeConverter
    fun incomeTypeToString(type: IncomeType?): String? = type?.name

    @TypeConverter
    fun fromIncomeStatus(value: String?): IncomeStatus? = value?.let { IncomeStatus.valueOf(it) }

    @TypeConverter
    fun incomeStatusToString(status: IncomeStatus?): String? = status?.name

    @TypeConverter
    fun fromExpenseExperience(value: String?): ExpenseExperience? = value?.let { ExpenseExperience.valueOf(it) }

    @TypeConverter
    fun expenseExperienceToString(experience: ExpenseExperience?): String? = experience?.name
}*/