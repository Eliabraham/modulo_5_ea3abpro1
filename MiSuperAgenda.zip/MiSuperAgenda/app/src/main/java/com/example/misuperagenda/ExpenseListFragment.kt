package com.example.misuperagenda.ui.fragments

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.misuperagenda.data.database.AppDatabase
import com.example.misuperagenda.data.model.Expense
import com.example.misuperagenda.data.repository.ExpenseRepository
import com.example.misuperagenda.databinding.FragmentExpenseListBinding
import com.example.misuperagenda.ui.ExpenseDetailActivity
import com.example.misuperagenda.ui.adapter.ExpenseAdapter
import com.example.misuperagenda.ui.viewmodel.ExpenseViewModel
import com.example.misuperagenda.ui.viewmodel.ExpenseViewModelFactory

class ExpenseListFragment : Fragment() {
    private var _binding: FragmentExpenseListBinding? = null
    private val binding get() = _binding!!

    private val expenseViewModel: ExpenseViewModel by activityViewModels {
        val database = AppDatabase.getDatabase(requireContext())
        val expenseDao = database.expenseDao()
        val expenseItemDao = database.expenseItemDao()
        val financialAccountDao = database.financialAccountDao()
        val repository = ExpenseRepository(expenseDao, financialAccountDao, expenseItemDao)
        ExpenseViewModelFactory(repository)
    }

    private lateinit var expenseAdapter: ExpenseAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentExpenseListBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecyclerView()
        setupFab()
        observeExpenses()
    }

    private fun setupRecyclerView() {
        expenseAdapter = ExpenseAdapter { expense ->
            val intent = Intent(requireContext(), ExpenseDetailActivity::class.java).apply {
                putExtra("EXPENSE_ID", expense.id)
            }
            startActivity(intent)
        }

        binding.recyclerViewExpenses.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = expenseAdapter
        }
    }

    private fun setupFab() {
        binding.fabAddExpense.setOnClickListener {
            val intent = Intent(requireContext(), ExpenseDetailActivity::class.java)
            startActivity(intent)
        }
    }

    private fun observeExpenses() {
        expenseViewModel.allExpenses.observe(viewLifecycleOwner) { expenses: List<Expense>? ->
            val expenseList = expenses ?: emptyList()
            expenseAdapter.submitList(expenseList)

            // Mostrar/ocultar estado vacío
            if (expenseList.isEmpty()) {
                binding.textEmptyState.visibility = View.VISIBLE
                binding.recyclerViewExpenses.visibility = View.GONE
                binding.textTotalExpenses.visibility = View.GONE
            } else {
                binding.textEmptyState.visibility = View.GONE
                binding.recyclerViewExpenses.visibility = View.VISIBLE
                binding.textTotalExpenses.visibility = View.VISIBLE

                // Calcular total de egresos
                val total = expenseList.sumOf { it.realAmount }
                binding.textTotalExpenses.text = "Total Egresos: $${String.format("%.2f", total)}"
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}