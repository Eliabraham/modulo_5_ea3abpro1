package com.example.misuperagenda.data.database

import androidx.room.*
import com.example.misuperagenda.data.model.Income
import kotlinx.coroutines.flow.Flow

@Dao
interface IncomeDao {

    /**
     * Inserta un nuevo ingreso o reemplaza uno existente (si el ID coincide).
     * @return El ID del ingreso insertado/actualizado.
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(income: Income): Long

    /**
     * Actualiza un ingreso existente.
     */
    @Update
    suspend fun update(income: Income)

    /**
     * Elimina un ingreso.
     */
    @Delete
    suspend fun delete(income: Income)

    /**
     * Obtiene todos los ingresos, ordenados por fecha descendente.
     */
    @Query("SELECT * FROM incomes ORDER BY incomeDate DESC")
    fun getAllIncomes(): Flow<List<Income>>

    /**
     * Obtiene un ingreso por su ID.
     */
    @Query("SELECT * FROM incomes WHERE id = :id")
    suspend fun getIncomeById(id: Int): Income?

    /**
     * Obtiene todos los ingresos asociados a una cuenta específica, ordenados por fecha.
     */
    @Query("SELECT * FROM incomes WHERE accountId = :accountId ORDER BY incomeDate DESC")
    fun getIncomesByAccountId(accountId: Int): Flow<List<Income>>

    /**
     * Obtiene todos los ingresos que están marcados para ser aplicados al saldo.
     * Esto es útil para la lógica de conciliación del repositorio.
     */
    @Query("SELECT * FROM incomes WHERE status = 'COBRADO' AND hasAppliedToBalance = 0")
    suspend fun getPendingToApplyIncomes(): List<Income>

}