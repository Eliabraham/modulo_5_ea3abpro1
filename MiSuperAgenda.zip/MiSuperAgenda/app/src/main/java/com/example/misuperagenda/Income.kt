package com.example.misuperagenda.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.time.LocalDateTime

/**
 * Entidad de Room para un registro de Ingreso (Income).
 *
 * @property id ID único del ingreso (autogenerado).
 * @property title Título breve del ingreso.
 * @property incomeDate Fecha en la que se espera/realiza el ingreso.
 * @property accountId ID de la cuenta financiera afectada.
 * @property description Descripción detallada.
 * @property amount Monto del ingreso.
 * @property type Tipo de ingreso (Sueldo, Venta, etc.).
 * @property status Estado del ingreso (Por Cobrar/Cobrado).
 * @property hasAppliedToBalance Indica si este registro ya ha modificado el balance de la cuenta.
 */
@Entity(tableName = "incomes")
data class Income(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val title: String,
    val incomeDate: LocalDateTime,
    val accountId: Int,
    val description: String? = null,
    val amount: Double,
    val type: IncomeType,
    val status: IncomeStatus,
    val hasAppliedToBalance: Boolean = false // **CLAVE:** Indica si el monto ya fue sumado al balance.
)