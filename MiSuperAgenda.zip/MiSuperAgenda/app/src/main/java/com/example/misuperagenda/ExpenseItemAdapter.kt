package com.example.misuperagenda.ui.adapter

import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.misuperagenda.data.model.ExpenseItem
import com.example.misuperagenda.databinding.ItemExpenseItemBinding

class ExpenseItemAdapter(
    private var items: MutableList<ExpenseItem>,
    private val onItemChange: () -> Unit,
    private val onDeleteItem: (Int) -> Unit
) : RecyclerView.Adapter<ExpenseItemAdapter.ExpenseItemViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ExpenseItemViewHolder {
        val binding = ItemExpenseItemBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ExpenseItemViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ExpenseItemViewHolder, position: Int) {
        holder.bind(items[position], position)
    }

    override fun getItemCount(): Int = items.size

    inner class ExpenseItemViewHolder(
        private val binding: ItemExpenseItemBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(item: ExpenseItem, position: Int) {
            binding.editDetail.setText(item.detail)
            binding.editQuantity.setText(item.quantity.toString())
            binding.editPresupuestadoPrice.setText(item.presupuestadoPrice.toString())
            binding.editUnitPrice.setText(item.unitPrice.toString())
            updateItemAmount(item)

            setupTextWatchers(position)
            binding.buttonDeleteItem.setOnClickListener { onDeleteItem(position) }
        }

        private fun setupTextWatchers(position: Int) {
            binding.editDetail.addTextChangedListener(createTextWatcher { newValue ->
                items[position] = items[position].copy(detail = newValue)
            })

            binding.editQuantity.addTextChangedListener(createTextWatcher { newValue ->
                val quantity = newValue.toDoubleOrNull() ?: 0.0
                items[position] = items[position].copy(quantity = quantity)
                updateItemAmount(items[position])
                onItemChange()
            })

            binding.editPresupuestadoPrice.addTextChangedListener(createTextWatcher { newValue ->
                val price = newValue.toDoubleOrNull() ?: 0.0
                items[position] = items[position].copy(presupuestadoPrice = price)
                onItemChange()
            })

            binding.editUnitPrice.addTextChangedListener(createTextWatcher { newValue ->
                val price = newValue.toDoubleOrNull() ?: 0.0
                items[position] = items[position].copy(unitPrice = price)
                updateItemAmount(items[position])
                onItemChange()
            })
        }

        private fun updateItemAmount(item: ExpenseItem) {
            val amount = item.quantity * item.unitPrice
            binding.textItemAmount.text = "$${String.format("%.2f", amount)}"
        }

        private fun createTextWatcher(onTextChanged: (String) -> Unit): TextWatcher {
            return object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    onTextChanged(s.toString())
                }
            }
        }
    }
}