package com.example.misuperagenda.ui

import android.app.Activity
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.ContactsContract
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.misuperagenda.R
import com.example.misuperagenda.data.database.AppDatabase
import com.example.misuperagenda.data.model.Categoria
import com.example.misuperagenda.data.model.Event
import com.example.misuperagenda.data.repository.EventRepository
import com.example.misuperagenda.ui.viewmodel.EventViewModel
import com.example.misuperagenda.ui.viewmodel.EventViewModelFactory
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import com.google.android.material.materialswitch.MaterialSwitch
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Calendar
import android.net.Uri
import com.example.misuperagenda.data.model.Estado

class EventDetailActivity : AppCompatActivity() {
    private lateinit var textDetailTitle: TextView
    private lateinit var editTitle: TextInputEditText
    private lateinit var editDescription: TextInputEditText
    private lateinit var editNotes: TextInputEditText
    private lateinit var spinnerCategory: Spinner
    private lateinit var spinnerStatus: Spinner
    private lateinit var editStartDate: TextInputEditText
    private lateinit var editStartTime: TextInputEditText
    private lateinit var editEndDate: TextInputEditText
    private lateinit var editEndTime: TextInputEditText
    private lateinit var editLocation: TextInputEditText
    private lateinit var inputContactNumber: TextInputLayout
    private lateinit var editContactNumber: TextInputEditText
    private lateinit var buttonContactActions: Button
    private lateinit var switchIsRepeating: MaterialSwitch
    private lateinit var buttonDelete: Button
    private lateinit var buttonSave: Button
    private lateinit var buttonOpenMap: Button

    // ViewModel y Datos
    private val viewModel: EventViewModel by viewModels {
        val database = AppDatabase.getDatabase(applicationContext)
        val repository = EventRepository(database.eventDao())
        EventViewModelFactory(repository)
    }
    private var eventId: Int? = null
    private var currentEvent: Event? = null
    private var startDate: LocalDate? = null
    private var startTime: LocalTime? = null
    private var endDate: LocalDate? = null
    private var endTime: LocalTime? = null
    private val dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")
    private val timeFormatter = DateTimeFormatter.ofPattern("HH:mm")
    companion object {
        const val EXTRA_EVENT_ID = "event_id"
        fun newIntent(context: Context, eventId: Int? = null): Intent {
            return Intent(context, EventDetailActivity::class.java).apply {
                eventId?.let { putExtra(EXTRA_EVENT_ID, it) }
            }
        }
    }
    private val selectContactLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            handleContactSelection(result.data)
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_event_detail)

        // 1. Inicialización de TODAS las vistas con findViewById
        textDetailTitle = findViewById(R.id.text_detail_title)
        editTitle = findViewById(R.id.edit_title)
        editDescription = findViewById(R.id.edit_description)
        editNotes = findViewById(R.id.edit_notes)
        spinnerCategory = findViewById(R.id.spinner_category)
        editStartDate = findViewById(R.id.edit_start_date)
        editStartTime = findViewById(R.id.edit_start_time)
        editEndDate = findViewById(R.id.edit_end_date)
        editEndTime = findViewById(R.id.edit_end_time)
        editLocation = findViewById(R.id.edit_location)
        inputContactNumber = findViewById(R.id.input_contact_number)
        editContactNumber = findViewById(R.id.edit_contact_number)
        buttonContactActions = findViewById(R.id.button_contact_actions)
        switchIsRepeating = findViewById(R.id.switch_is_repeating)
        buttonDelete = findViewById(R.id.button_delete)
        buttonSave = findViewById(R.id.button_save)
        buttonOpenMap = findViewById(R.id.button_open_map)
        spinnerStatus = findViewById(R.id.spinner_status)

        // 2. Configuración
        setResult(Activity.RESULT_CANCELED)
        setupCategorySpinner()
        setupStatusSpinner()
        setupDateTimePickers()
        setupSaveButton()
        setupDeleteButton()
        setupContactPicker()
        setupContactActionsButton()
        setupMapButton()

        // 3. Lógica de carga
        eventId = intent.getIntExtra(EXTRA_EVENT_ID, -1).takeIf { it != -1 }
        eventId?.let { loadEventDetails(it) } ?: setupNewEventDefaults()
    }
    private fun setupMapButton() {
        // Conexión del botón de Maps al listener
        buttonOpenMap.setOnClickListener {
            openLocationInMaps()
        }
    }
    private fun openLocationInMaps() {
        val locationText = editLocation.text.toString().trim()
        if (locationText.isEmpty()) {
            Toast.makeText(this, "Por favor, ingresa una ubicación primero para abrir el mapa.", Toast.LENGTH_SHORT).show()
            return
        }
        val encodedLocation = Uri.encode(locationText)
        val mapUri = Uri.parse("https://maps.google.com/maps/search/?api=1&query=$encodedLocation")
        val explicitMapIntent = Intent(Intent.ACTION_VIEW, mapUri).apply {
            setPackage("com.google.android.apps.maps")
        }

        try {
            startActivity(explicitMapIntent)
            return // Si funciona, salimos de la función
        } catch (e: Exception) {
            // Falla si Google Maps no está instalado o el paquete no se encuentra
            // Continuamos con el Intento B (opción universal)
        }

        // 4. Intento B: Abrir con cualquier aplicación que maneje la URL (navegador, otra app de mapas)
        val genericMapIntent = Intent(Intent.ACTION_VIEW, mapUri)

        if (genericMapIntent.resolveActivity(packageManager) != null) {
            startActivity(genericMapIntent)
        } else {
            // Muestra un mensaje si no se encuentra ninguna aplicación compatible (ni Maps forzado, ni navegador)
            Toast.makeText(this, "No se encontró ninguna aplicación de mapas o navegador compatible para abrir la ubicación.", Toast.LENGTH_LONG).show()
        }
    }
    private fun setupContactPicker() {
        // Aquí usamos el TextInputLayout (input_contact_number) para el ícono de contacto, que es correcto
        // Se asume que el input_contact_number existe en el XML
        findViewById<TextInputLayout>(R.id.input_contact_number).setEndIconOnClickListener {
            openContactPicker()
        }
    }
    private fun setupStatusSpinner() {
        spinnerStatus.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            // Usamos el array de strings que definiste en strings.xml
            resources.getStringArray(R.array.task_status_array)
        )
    }
    private fun openContactPicker() {
        val intent = Intent(
            Intent.ACTION_PICK,
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        )
        selectContactLauncher.launch(intent)
    }
    private fun handleContactSelection(data: Intent?) {
        val contactUri: android.net.Uri? = data?.data
        contactUri ?: return
        val projection = arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER)
        contentResolver.query(contactUri, projection, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val numberIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                val newPhoneNumber = cursor.getString(numberIndex).replace("[^0-9+]".toRegex(), "")
                val currentText = editContactNumber.text.toString().trim()
                val updatedText = if (currentText.isEmpty()) {
                    newPhoneNumber
                } else {
                    "$currentText, $newPhoneNumber"
                }
                editContactNumber.setText(updatedText)
                buttonContactActions.visibility = View.VISIBLE
                Toast.makeText(this, "Contacto añadido: $newPhoneNumber", Toast.LENGTH_SHORT).show()
            }
        }
    }
    private fun setupContactActionsButton() {
        buttonContactActions.setOnClickListener {
            val phoneNumber = editContactNumber.text.toString().trim()
            if (phoneNumber.isNotEmpty()) {
                showCommunicationOptions(phoneNumber)
            } else {
                Toast.makeText(this, "Debe seleccionar o ingresar un número de contacto.", Toast.LENGTH_SHORT).show()
            }
        }
    }
    private fun showCommunicationOptions(phoneNumber: String) {
        val items = arrayOf("Llamar", "Enviar Mensaje SMS", "Enviar WhatsApp")
        AlertDialog.Builder(this)
            .setTitle("Acciones para $phoneNumber")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> makeCall(phoneNumber)
                    1 -> sendSms(phoneNumber)
                    2 -> sendWhatsApp(phoneNumber)
                }
            }
            .show()
    }
    private fun makeCall(phoneNumber: String) {
        val intent = Intent(Intent.ACTION_CALL).apply {
            data = android.net.Uri.parse("tel:$phoneNumber")
        }
        startActivity(intent)
    }
    private fun sendSms(phoneNumber: String) {
        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = android.net.Uri.parse("smsto:$phoneNumber")
        }
        startActivity(intent)
    }
    private fun sendWhatsApp(phoneNumber: String) {
        try {
            val whatsAppUri = android.net.Uri.parse("https://api.whatsapp.com/send?phone=$phoneNumber&text=Te invito a mi evento: ${currentEvent?.title}")
            val whatsAppIntent = Intent(Intent.ACTION_VIEW, whatsAppUri)
            startActivity(whatsAppIntent)
        } catch (e: Exception) {
            Toast.makeText(this, "WhatsApp no está instalado.", Toast.LENGTH_SHORT).show()
        }
    }
    private fun setupCategorySpinner() {
        spinnerCategory.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            Categoria.entries.map { it.name }
        )
    }
    private fun setupDateTimePickers() {
        editStartDate.setOnClickListener { showDatePicker(isStart = true) }
        editStartTime.setOnClickListener { showTimePicker(isStart = true) }
        editEndDate.setOnClickListener { showDatePicker(isStart = false) }
        editEndTime.setOnClickListener { showTimePicker(isStart = false) }
    }
    private fun setupNewEventDefaults() {
        textDetailTitle.text = getString(R.string.new_event_title)
        buttonDelete.visibility = View.GONE
        val now = LocalDateTime.now().plusHours(1)
        startDate = now.toLocalDate()
        startTime = now.toLocalTime()
        endDate = now.toLocalDate()
        endTime = now.toLocalTime().plusHours(1)
        updateDateFields()
    }
    private fun loadEventDetails(id: Int) {
        textDetailTitle.text = getString(R.string.edit_event_title)
        buttonDelete.visibility = View.VISIBLE
        lifecycleScope.launch {
            currentEvent = viewModel.repository.getEventById(id)
            currentEvent?.let { event ->
                // Campos existentes
                editTitle.setText(event.title)
                editDescription.setText(event.description)
                editLocation.setText(event.locationName)
                editNotes.setText(event.notes)
                switchIsRepeating.isChecked = event.isRepeating

                // Lógica de fechas (asumiendo que tienes un ToLocalDate() o similar)
                // (Debes adaptar esto si tus DATES no son de tipo java.util.Date)
                // Aquí lo mantengo basado en tu código anterior:
                startDate = event.startTime.toLocalDate()
                startTime = event.startTime.toLocalTime()
                endDate = event.endTime.toLocalDate()
                endTime = event.endTime.toLocalTime()
                updateDateFields()

                // Cargar Categoria
                val categoryName = event.category.name
                val categoryPosition = Categoria.entries.indexOfFirst { it.name == categoryName }
                spinnerCategory.setSelection(categoryPosition)

                // CARGAR ESTADO (NUEVO)
                val statusPosition = Estado.entries.indexOfFirst { it == event.estado }
                if (statusPosition >= 0) {
                    spinnerStatus.setSelection(statusPosition)
                }
                event.guests?.let { guestsList ->
                    val guestsString = guestsList.joinToString(separator = ", ")
                    editContactNumber.setText(guestsString)
                    buttonContactActions.visibility = View.VISIBLE
                } ?: run {
                    buttonContactActions.visibility = View.GONE
                }
            } ?: run {
                Toast.makeText(this@EventDetailActivity, "Evento no encontrado", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }
    private fun updateDateFields() {
        editStartDate.setText(startDate?.format(dateFormatter))
        editStartTime.setText(startTime?.format(timeFormatter))
        editEndDate.setText(endDate?.format(dateFormatter))
        editEndTime.setText(endTime?.format(timeFormatter))
    }
    private fun showDatePicker(isStart: Boolean) {
        val c = Calendar.getInstance()
        val initialDate = (if (isStart) startDate else endDate) ?: LocalDate.now()
        c.set(initialDate.year, initialDate.monthValue - 1, initialDate.dayOfMonth)
        val dialog = DatePickerDialog(
            this,
            { _, year, monthOfYear, dayOfMonth ->
                val selectedDate = LocalDate.of(year, monthOfYear + 1, dayOfMonth)
                if (isStart) {
                    startDate = selectedDate
                } else {
                    endDate = selectedDate
                }
                updateDateFields()
            },
            c.get(Calendar.YEAR),
            c.get(Calendar.MONTH),
            c.get(Calendar.DAY_OF_MONTH)
        )
        dialog.show()
    }
    private fun showTimePicker(isStart: Boolean) {
        val c = Calendar.getInstance()
        val initialTime = (if (isStart) startTime else endTime) ?: LocalTime.of(c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE))
        val dialog = TimePickerDialog(
            this,
            { _, hourOfDay, minute ->
                val selectedTime = LocalTime.of(hourOfDay, minute)
                if (isStart) {
                    startTime = selectedTime
                    if (eventId == null && endDate == startDate && endTime == null) {
                        endTime = selectedTime.plusHours(1)
                        endDate = startDate
                    }
                } else {
                    endTime = selectedTime
                }
                updateDateFields()
            },
            initialTime.hour,
            initialTime.minute,
            true // formato de 24 horas
        )
        dialog.show()
    }
    private fun validateAndSaveEvent() {
        val title = editTitle.text.toString().trim()
        val description = editDescription.text.toString().trim()
        val location = editLocation.text.toString().trim().takeIf { it.isNotEmpty() }
        val isRepeating = switchIsRepeating.isChecked
        val notes = editNotes.text.toString().trim().takeIf { it.isNotEmpty() }
        var errorMessage: String? = null
        if (title.isEmpty()) {
            errorMessage = "El título del evento es obligatorio (*)."
        } else if (startDate == null || startTime == null || endDate == null || endTime == null) {
            errorMessage = "Las fechas y horas de inicio/fin son obligatorias (*)."
        }
        if (errorMessage != null) {
            AlertDialog.Builder(this)
                .setTitle("Campos Incompletos")
                .setMessage(errorMessage)
                .setPositiveButton("Aceptar") { dialog, _ -> dialog.dismiss() }
                .show()
            return
        }
        val startDateTime = LocalDateTime.of(startDate!!, startTime!!)
        val endDateTime = LocalDateTime.of(endDate!!, endTime!!)
        if (startDateTime.isAfter(endDateTime)) {
            AlertDialog.Builder(this)
                .setTitle("Error de Horario")
                .setMessage("La hora de inicio debe ser anterior a la hora de fin.")
                .setPositiveButton("Aceptar") { dialog, _ -> dialog.dismiss() }
                .show()
            return
        }
        // Capturar Categoria
        val categoryString = spinnerCategory.selectedItem.toString()
        val category = try {
            Categoria.valueOf(categoryString)
        } catch (e: IllegalArgumentException) {
            Categoria.OTRO
        }
        // CAPTURAR ESTADO (NUEVO)
        val selectedStatusPosition = spinnerStatus.selectedItemPosition
        val estado = Estado.entries[selectedStatusPosition]
        // Capturar Contactos
        val rawContactText = editContactNumber.text.toString().trim()
        val guestsList: List<String>? = if (rawContactText.isNotEmpty()) {
            rawContactText
                .split(',')
                .map { it.trim().replace("[^0-9+]".toRegex(), "") }
                .filter { it.isNotEmpty() }
                .takeIf { it.isNotEmpty() }
        } else {
            null
        }
        // Construir el evento (Event) con el nuevo campo de estado
        val eventToSave = currentEvent?.copy(
            title = title,
            description = description,
            category = category,
            startTime = startDateTime,
            endTime = endDateTime,
            locationName = location,
            isRepeating = isRepeating,
            guests = guestsList,
            notes = notes,
            estado = estado
        ) ?: Event(
            title = title,
            description = description,
            category = category,
            startTime = startDateTime,
            endTime = endDateTime,
            locationName = location,
            isRepeating = isRepeating,
            guests = guestsList,
            notes = notes,
            estado = estado
        )
        viewModel.insertOrUpdate(eventToSave) { success, message ->
            if (success) {
                //Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
                val action = if (eventId == null) "guardada" else "editada"
                setResult(Activity.RESULT_OK, Intent().putExtra("action", action))
                finish()
            } else {
                //Toast.makeText(this, message, Toast.LENGTH_LONG).show()
            }
        }
    }
    private fun setupSaveButton() {
        buttonSave.setOnClickListener {
            validateAndSaveEvent()
        }
    }
    private fun setupDeleteButton() {
        buttonDelete.setOnClickListener {
            showDeleteConfirmationDialog()
        }
    }
    private fun showDeleteConfirmationDialog() {
        AlertDialog.Builder(this)
            .setTitle("Confirmar Eliminación")
            .setMessage("¿Estás seguro de que quieres eliminar este evento?")
            .setPositiveButton("Sí, Eliminar") { dialog, _ ->
                currentEvent?.let { event ->
                    viewModel.delete(event)
                    Toast.makeText(this, "Evento eliminado.", Toast.LENGTH_SHORT).show()
                    val resultIntent = Intent().putExtra("action", "eliminada")
                    setResult(Activity.RESULT_OK, resultIntent)
                    finish()
                }
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }
}
