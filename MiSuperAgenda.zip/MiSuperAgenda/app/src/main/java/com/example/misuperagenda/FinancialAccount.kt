package com.example.misuperagenda.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "financial_accounts")
data class FinancialAccount(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val institution: String,           // Ej: "Banco Nacional", "Caja Chica", "Billetera Móvil"
    val accountNumber: String,         // Ej: "123-456789", "Efectivo", "1234****5678"
    val accountType: String,           // Ej: "Ahorros", "Corriente", "Caja Chica", "Billetera", "Tarjeta Débito"
    val balance: Double,               // Saldo actual
    val currency: String = "USD",      // Moneda
    val description: String? = null,   // Descripción opcional
    val isActive: Boolean = true       // Si la cuenta está activa
)