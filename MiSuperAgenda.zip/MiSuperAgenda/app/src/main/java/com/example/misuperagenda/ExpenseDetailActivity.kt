package com.example.misuperagenda.ui

import android.app.Activity
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.misuperagenda.R
import com.example.misuperagenda.data.database.AppDatabase
import com.example.misuperagenda.data.model.*
import com.example.misuperagenda.data.repository.ExpenseRepository
import com.example.misuperagenda.data.repository.FinancialAccountRepository
import com.example.misuperagenda.databinding.ActivityExpenseDetailBinding
import com.example.misuperagenda.ui.adapter.ExpenseItemAdapter
import com.example.misuperagenda.ui.viewmodel.ExpenseViewModel
import com.example.misuperagenda.ui.viewmodel.ExpenseViewModelFactory
import com.example.misuperagenda.ui.viewmodel.FinancialAccountViewModel
import com.example.misuperagenda.ui.viewmodel.FinancialAccountViewModelFactory
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Calendar

class ExpenseDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityExpenseDetailBinding
    private var expenseId: Int = 0
    private var currentExpense: Expense? = null
    private var selectedDate: LocalDate = LocalDate.now()
    private var selectedTime: LocalTime = LocalTime.now()
    private val expenseItems = mutableListOf<ExpenseItem>()

    // ViewModels
    private val expenseViewModel: ExpenseViewModel by viewModels {
        val database = AppDatabase.getDatabase(applicationContext)
        val expenseDao = database.expenseDao()
        val expenseItemDao = database.expenseItemDao()
        val financialAccountDao = database.financialAccountDao()
        val repository = ExpenseRepository(expenseDao, financialAccountDao, expenseItemDao)
        ExpenseViewModelFactory(repository)
    }

    private val financialAccountViewModel: FinancialAccountViewModel by viewModels {
        val database = AppDatabase.getDatabase(applicationContext)
        val repository = FinancialAccountRepository(database.financialAccountDao())
        FinancialAccountViewModelFactory(repository)
    }

    // Adapter para items
    private lateinit var expenseItemAdapter: ExpenseItemAdapter

    // Vistas
    private lateinit var textDetailTitle: TextView
    private lateinit var editTitle: TextInputEditText
    private lateinit var buttonSelectDate: Button
    private lateinit var buttonSelectTime: Button
    private lateinit var editDescription: TextInputEditText
    private lateinit var spinnerAccount: Spinner
    private lateinit var spinnerExpenseType: Spinner
    private lateinit var spinnerExpenseStatus: Spinner
    private lateinit var spinnerExperience: Spinner
    private lateinit var textTotalBudgeted: TextView
    private lateinit var textTotalReal: TextView
    private lateinit var buttonAddItem: Button
    private lateinit var buttonSave: Button
    private lateinit var buttonDelete: Button

    // Datos para Spinners
    private var accountList: List<FinancialAccount> = emptyList()

    companion object {
        private const val EXTRA_EXPENSE_ID = "EXPENSE_ID"

        fun newIntent(context: Context, expenseId: Int = 0): Intent {
            return Intent(context, ExpenseDetailActivity::class.java).apply {
                putExtra(EXTRA_EXPENSE_ID, expenseId)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityExpenseDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        expenseId = intent.getIntExtra(EXTRA_EXPENSE_ID, 0)
        initViews()
        setupRecyclerView()
        setupSpinners()
        setupListeners()

        if (expenseId != 0) {
            textDetailTitle.text = "Editar Egreso"
            buttonDelete.visibility = View.VISIBLE
            loadExpenseData(expenseId)
        } else {
            updateDateTimeButtons()
            textDetailTitle.text = "Nuevo Egreso"
            buttonDelete.visibility = View.GONE
            addEmptyItem()
        }
    }

    private fun initViews() {
        textDetailTitle = binding.textDetailTitle
        editTitle = binding.editTitle
        buttonSelectDate = binding.buttonSelectDate
        buttonSelectTime = binding.buttonSelectTime
        editDescription = binding.editDescription
        spinnerAccount = binding.spinnerAccount
        spinnerExpenseType = binding.spinnerExpenseType
        spinnerExpenseStatus = binding.spinnerExpenseStatus
        spinnerExperience = binding.spinnerExperience
        textTotalBudgeted = binding.textTotalBudgeted
        textTotalReal = binding.textTotalReal
        buttonAddItem = binding.buttonAddItem
        buttonSave = binding.buttonSave
        buttonDelete = binding.buttonDelete
    }

    private fun setupRecyclerView() {
        expenseItemAdapter = ExpenseItemAdapter(expenseItems,
            onItemChange = { calculateTotals() },
            onDeleteItem = { position ->
                expenseItems.removeAt(position)
                expenseItemAdapter.notifyDataSetChanged()
                calculateTotals()
            }
        )

        binding.recyclerViewItems.apply {
            layoutManager = LinearLayoutManager(this@ExpenseDetailActivity)
            adapter = expenseItemAdapter
        }
    }

    private fun setupSpinners() {
        // Spinner Tipo de Egreso
        ArrayAdapter.createFromResource(
            this,
            R.array.expense_types_array,
            android.R.layout.simple_spinner_item
        ).also { adapter ->
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            spinnerExpenseType.adapter = adapter
        }

        // Spinner Estado de Egreso
        ArrayAdapter.createFromResource(
            this,
            R.array.expense_status_array,
            android.R.layout.simple_spinner_item
        ).also { adapter ->
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            spinnerExpenseStatus.adapter = adapter
        }

        // Spinner Experiencia
        ArrayAdapter.createFromResource(
            this,
            R.array.expense_experience_array,
            android.R.layout.simple_spinner_item
        ).also { adapter ->
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            spinnerExperience.adapter = adapter
        }

        // Spinner Cuentas Bancarias
        lifecycleScope.launch {
            financialAccountViewModel.allAccounts.collect { accounts ->
                accountList = accounts
                val accountNames = accounts.map { "${it.institution} (${it.accountType})" }
                val accountAdapter = ArrayAdapter(
                    this@ExpenseDetailActivity,
                    android.R.layout.simple_spinner_dropdown_item,
                    accountNames
                )
                spinnerAccount.adapter = accountAdapter

                if (expenseId != 0 && currentExpense != null) {
                    prepopulateFields()
                }
            }
        }
    }

    private fun setupListeners() {
        buttonSelectDate.setOnClickListener { showDatePickerDialog() }
        buttonSelectTime.setOnClickListener { showTimePickerDialog() }
        buttonAddItem.setOnClickListener { addEmptyItem() }
        buttonSave.setOnClickListener { validateAndSaveExpense() }
        buttonDelete.setOnClickListener { showDeleteConfirmationDialog() }
    }

    private fun addEmptyItem() {
        expenseItems.add(ExpenseItem(
            expenseId = 0,
            detail = "",
            quantity = 1.0,
            unitPrice = 0.0,
            presupuestadoPrice = 0.0,
            itemAmount = 0.0
        ))
        expenseItemAdapter.notifyDataSetChanged()
        calculateTotals()
    }

    private fun loadExpenseData(id: Int) = lifecycleScope.launch {
        val expenseWithItems = expenseViewModel.getExpenseWithItemsById(id)
        if (expenseWithItems == null) {
            Toast.makeText(this@ExpenseDetailActivity, "Egreso no encontrado.", Toast.LENGTH_SHORT).show()
            finish()
            return@launch
        }

        currentExpense = expenseWithItems.expense
        expenseItems.clear()
        expenseItems.addAll(expenseWithItems.items)
        expenseItemAdapter.notifyDataSetChanged()

        if (accountList.isNotEmpty()) {
            prepopulateFields()
        }
        calculateTotals()
    }

    private fun prepopulateFields() {
        currentExpense?.let { expense ->
            editTitle.setText(expense.title)
            editDescription.setText(expense.description)

            selectedDate = expense.expenseDate.toLocalDate()
            selectedTime = expense.expenseDate.toLocalTime()
            updateDateTimeButtons()

            // Preseleccionar spinners
            setSpinnerSelection(spinnerExpenseType, expense.expenseType.name)
            setSpinnerSelection(spinnerExpenseStatus, expense.expenseStatus.name)
            expense.experience?.let { exp -> setSpinnerSelection(spinnerExperience, exp.name) }

            val accountPosition = accountList.indexOfFirst { it.id == expense.accountId }
            if (accountPosition != -1) spinnerAccount.setSelection(accountPosition)
        }
    }

    private fun setSpinnerSelection(spinner: Spinner, value: String) {
        for (i in 0 until spinner.count) {
            if (spinner.getItemAtPosition(i).toString() == value) {
                spinner.setSelection(i)
                return
            }
        }
    }

    private fun showDatePickerDialog() {
        val calendar = Calendar.getInstance().apply {
            set(selectedDate.year, selectedDate.monthValue - 1, selectedDate.dayOfMonth)
        }

        DatePickerDialog(
            this,
            { _, year, month, dayOfMonth ->
                selectedDate = LocalDate.of(year, month + 1, dayOfMonth)
                updateDateTimeButtons()
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    private fun showTimePickerDialog() {
        val calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, selectedTime.hour)
            set(Calendar.MINUTE, selectedTime.minute)
        }

        TimePickerDialog(
            this,
            { _, hourOfDay, minute ->
                selectedTime = LocalTime.of(hourOfDay, minute)
                updateDateTimeButtons()
            },
            calendar.get(Calendar.HOUR_OF_DAY),
            calendar.get(Calendar.MINUTE),
            true
        ).show()
    }

    private fun updateDateTimeButtons() {
        val dateFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy")
        val timeFormatter = DateTimeFormatter.ofPattern("HH:mm")
        buttonSelectDate.text = selectedDate.format(dateFormatter)
        buttonSelectTime.text = selectedTime.format(timeFormatter)
    }

    private fun calculateTotals() {
        val totalBudgeted = expenseItems.sumOf { it.quantity * it.presupuestadoPrice }
        val totalReal = expenseItems.sumOf { it.quantity * it.unitPrice }

        textTotalBudgeted.text = "Total Presupuestado: $${String.format("%.2f", totalBudgeted)}"
        textTotalReal.text = "Total Real: $${String.format("%.2f", totalReal)}"
    }

    private fun validateAndSaveExpense() {
        val title = editTitle.text.toString().trim()
        val description = editDescription.text.toString().trim()
        val selectedAccountIndex = spinnerAccount.selectedItemPosition

        if (title.isEmpty() || selectedAccountIndex == -1) {
            Toast.makeText(this, "Por favor, completa todos los campos obligatorios.", Toast.LENGTH_LONG).show()
            return
        }

        if (expenseItems.isEmpty()) {
            Toast.makeText(this, "Debe agregar al menos un item al egreso.", Toast.LENGTH_LONG).show()
            return
        }

        // Validar items
        for ((index, item) in expenseItems.withIndex()) {
            if (item.detail.trim().isEmpty() || item.quantity <= 0 || item.unitPrice < 0 || item.presupuestadoPrice < 0) {
                Toast.makeText(this, "El item ${index + 1} tiene campos inválidos.", Toast.LENGTH_LONG).show()
                return
            }
        }

        val selectedAccount = accountList[selectedAccountIndex]
        val selectedType = ExpenseType.valueOf(spinnerExpenseType.selectedItem.toString())
        val selectedStatus = ExpenseStatus.valueOf(spinnerExpenseStatus.selectedItem.toString())
        val selectedExperience = ExpenseExperience.valueOf(spinnerExperience.selectedItem.toString())

        val expenseDateTime = LocalDateTime.of(selectedDate, selectedTime)

        // Calcular totales finales
        val totalBudgeted = expenseItems.sumOf { it.quantity * it.presupuestadoPrice }
        val totalReal = expenseItems.sumOf { it.quantity * it.unitPrice }

        val expenseToSave = currentExpense?.copy(
            title = title,
            expenseDate = expenseDateTime,
            accountId = selectedAccount.id,
            description = description,
            budgetedAmount = totalBudgeted,
            realAmount = totalReal,
            expenseType = selectedType,
            expenseStatus = selectedStatus,
            experience = selectedExperience
        ) ?: Expense(
            title = title,
            expenseDate = expenseDateTime,
            accountId = selectedAccount.id,
            description = description,
            budgetedAmount = totalBudgeted,
            realAmount = totalReal,
            expenseType = selectedType,
            expenseStatus = selectedStatus,
            experience = selectedExperience
        )

        val expenseWithItems = ExpenseWithItems(expenseToSave, expenseItems)
        expenseViewModel.insertOrUpdate(expenseWithItems)

        Toast.makeText(this, "Egreso ${if (expenseId == 0) "guardado" else "editado"} exitosamente.", Toast.LENGTH_SHORT).show()
        setResult(Activity.RESULT_OK)
        finish()
    }

    private fun showDeleteConfirmationDialog() {
        AlertDialog.Builder(this)
            .setTitle("Confirmar Eliminación")
            .setMessage("¿Estás seguro de que quieres eliminar este Egreso?")
            .setPositiveButton("Sí, Eliminar") { dialog, _ ->
                currentExpense?.let { expense ->
                    expenseViewModel.delete(expense)
                    Toast.makeText(this, "Egreso eliminado.", Toast.LENGTH_SHORT).show()
                    setResult(Activity.RESULT_OK)
                    finish()
                }
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar") { dialog, _ -> dialog.dismiss() }
            .show()
    }
}