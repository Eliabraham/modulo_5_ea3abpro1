package com.example.misuperagenda.data.model
enum class Estado {
    PENDIENTE,       // Tarea creada, lista para ser iniciada
    EN_PROCESO,      // Tarea en ejecución
    PAUSADO,         // Tarea detenida temporalmente
    CANCELADO,       // Tarea descartada
    COMPLETADO       // Tarea finalizada exitosamente
}
