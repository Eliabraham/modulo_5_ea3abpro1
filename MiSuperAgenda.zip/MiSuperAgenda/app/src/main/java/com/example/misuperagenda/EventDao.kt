package com.example.misuperagenda.data.database
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.misuperagenda.data.model.Event
import kotlinx.coroutines.flow.Flow
import java.time.LocalDateTime
@Dao
interface EventDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(event: Event): Long
    @Query("SELECT * FROM events ORDER BY startTime ASC")
    fun getAllEvents(): Flow<List<Event>>
    @Query("""
        SELECT * FROM events 
        WHERE id != :eventId 
        AND category != 'ALARMA' 
        AND (
            (startTime < :newEndTime AND endTime > :newStartTime) 
        )
    """)
    suspend fun findOverlappingEvents(
        eventId: Int,
        newStartTime: LocalDateTime,
        newEndTime: LocalDateTime
    ): List<Event>
    @Query("SELECT * FROM events WHERE category = :category ORDER BY startTime ASC")
    fun getEventsByCategory(category: String): Flow<List<Event>>
    @Query("SELECT * FROM events WHERE id = :id")
    suspend fun getEventById(id: Int): Event?
    @Update
    suspend fun update(event: Event)
    @Delete
    suspend fun delete(event: Event)
}