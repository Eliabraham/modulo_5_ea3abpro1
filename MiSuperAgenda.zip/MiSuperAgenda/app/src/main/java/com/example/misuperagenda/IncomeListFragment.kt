package com.example.misuperagenda.ui.fragments

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.misuperagenda.data.database.AppDatabase
import com.example.misuperagenda.data.repository.FinancialAccountRepository
import com.example.misuperagenda.data.repository.IncomeRepository
import com.example.misuperagenda.databinding.FragmentIncomeListBinding
import com.example.misuperagenda.ui.IncomeDetailActivity
import com.example.misuperagenda.ui.adapter.IncomeAdapter
import com.example.misuperagenda.ui.viewmodel.FinancialAccountViewModel
import com.example.misuperagenda.ui.viewmodel.FinancialAccountViewModelFactory
import com.example.misuperagenda.ui.viewmodel.IncomeViewModel
import com.example.misuperagenda.ui.viewmodel.IncomeViewModelFactory
class IncomeListFragment : Fragment() {
    private var _binding: FragmentIncomeListBinding? = null
    private val binding get() = _binding!!
    // Usaremos activityViewModels para que el ViewModel se comparta en el ámbito de la MainActivity
    private val incomeViewModel: IncomeViewModel by activityViewModels {
        val database = AppDatabase.getDatabase(requireContext())
        val incomeDao = database.incomeDao()
        val financialAccountDao = database.financialAccountDao()
        val repository = IncomeRepository(incomeDao, financialAccountDao)
        IncomeViewModelFactory(repository)
    }
    private val financialAccountViewModel: FinancialAccountViewModel by activityViewModels {
        val database = AppDatabase.getDatabase(requireContext())
        val repository = FinancialAccountRepository(database.financialAccountDao())
        FinancialAccountViewModelFactory(repository)
    }
    private lateinit var incomeAdapter: IncomeAdapter
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentIncomeListBinding.inflate(inflater, container, false)
        return binding.root
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecyclerView()
        setupFab()
        observeIncomes()
    }

    private fun setupRecyclerView() {
        incomeAdapter = IncomeAdapter(
            onItemClick = { income ->
                val intent = IncomeDetailActivity.newIntent(requireContext(), income.id)
                startActivity(intent)
            },
            // Le pasamos el ViewModel de cuentas para que el adapter pueda buscar el nombre de la cuenta
            financialAccountViewModel = financialAccountViewModel,
            // SOLUCIÓN: Agregamos el lifecycleOwner aquí
            lifecycleOwner = viewLifecycleOwner
        )
        binding.recyclerViewIncomes.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = incomeAdapter
        }
    }

    /*private fun setupRecyclerView() {
        incomeAdapter = IncomeAdapter(
            onItemClick = { income ->
                val intent = IncomeDetailActivity.newIntent(requireContext(), income.id)
                startActivity(intent)
            },
            // Le pasamos el ViewModel de cuentas para que el adapter pueda buscar el nombre de la cuenta
            financialAccountViewModel = financialAccountViewModel
        )
        binding.recyclerViewIncomes.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = incomeAdapter
        }
    }*/
    private fun setupFab() {
        binding.fabAddIncome.setOnClickListener {
            val intent = IncomeDetailActivity.newIntent(requireContext())
            startActivity(intent)
        }
    }
    private fun observeIncomes() {
        incomeViewModel.allIncomes.observe(viewLifecycleOwner) { incomes ->
            incomeAdapter.submitList(incomes)
            // Lógica para mostrar/ocultar mensaje de vacío
            binding.textEmptyState.visibility = if (incomes.isEmpty()) View.VISIBLE else View.GONE
            binding.recyclerViewIncomes.visibility = if (incomes.isEmpty()) View.GONE else View.VISIBLE
        }
    }
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}