package com.example.misuperagenda.ui.adapter

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.misuperagenda.data.model.Expense
import com.example.misuperagenda.data.model.ExpenseStatus
import com.example.misuperagenda.databinding.ItemExpenseBinding
import java.time.format.DateTimeFormatter

class ExpenseAdapter(
    private val onItemClick: (Expense) -> Unit
) : ListAdapter<Expense, ExpenseAdapter.ExpenseViewHolder>(ExpenseDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ExpenseViewHolder {
        val binding = ItemExpenseBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ExpenseViewHolder(binding, onItemClick)
    }

    override fun onBindViewHolder(holder: ExpenseViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class ExpenseViewHolder(
        private val binding: ItemExpenseBinding,
        private val onItemClick: (Expense) -> Unit
    ) : RecyclerView.ViewHolder(binding.root) {

        private val dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd")

        fun bind(expense: Expense) {
            binding.textExpenseTitle.text = expense.title
            binding.textExpenseAmount.text = "- $${String.format("%.2f", expense.realAmount)}"
            binding.textExpenseDate.text = expense.expenseDate.format(dateFormatter)
            binding.textExpenseType.text = expense.expenseType.name

            // Configurar estado con colores
            binding.textExpenseStatus.text = expense.expenseStatus.name
            when (expense.expenseStatus) {
                ExpenseStatus.PLANIFICADO -> {
                    binding.textExpenseStatus.setBackgroundColor(Color.parseColor("#FFA000"))
                    binding.textExpenseStatus.setTextColor(Color.WHITE)
                }
                ExpenseStatus.EJECUTADO -> {
                    binding.textExpenseStatus.setBackgroundColor(Color.parseColor("#4CAF50"))
                    binding.textExpenseStatus.setTextColor(Color.WHITE)
                }
            }

            // Mostrar diferencia entre presupuestado y real
            val difference = expense.budgetedAmount - expense.realAmount
            if (difference != 0.0) {
                binding.textBudgetDifference.visibility = View.VISIBLE
                val diffText = if (difference > 0) {
                    "Ahorro: $${String.format("%.2f", difference)}"
                } else {
                    "Exceso: $${String.format("%.2f", -difference)}"
                }
                binding.textBudgetDifference.text = diffText
            } else {
                binding.textBudgetDifference.visibility = View.GONE
            }

            binding.root.setOnClickListener {
                onItemClick(expense)
            }
        }
    }
}

class ExpenseDiffCallback : DiffUtil.ItemCallback<Expense>() {
    override fun areItemsTheSame(oldItem: Expense, newItem: Expense): Boolean {
        return oldItem.id == newItem.id
    }

    override fun areContentsTheSame(oldItem: Expense, newItem: Expense): Boolean {
        return oldItem == newItem
    }
}